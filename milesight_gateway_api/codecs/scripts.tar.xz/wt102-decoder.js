/**
 * Payload Decoder
 *
 * Copyright 2025 Milesight IoT
 *
 * @product WT102
 */

/* eslint no-redeclare: "off" */
/* eslint-disable */
// Chirpstack v4
function decodeUplink(input) {
	var decoded = milesightDeviceDecode(input.bytes);
	return { data: decoded };
}

// Chirpstack v3
function Decode(fPort, bytes) {
	return milesightDeviceDecode(bytes);
}

// The Things Network
function Decoder(bytes, port) {
	return milesightDeviceDecode(bytes);
}
/* eslint-enable */

function milesightDeviceDecode(bytes) {
	var decoded = {};
	var result = {};
	var history = [];

	var unknown_command = 0;
	var counterObj = {};
	for (counterObj.i = 0; counterObj.i < bytes.length; ) {
		var command_id = bytes[counterObj.i++];
		switch (command_id) {
			case 0xff:
				decoded.check_sequence_number_reply = decoded.check_sequence_number_reply || {};
				decoded.check_sequence_number_reply.sequence_number = readUInt8(bytes, counterObj, 1);
				break;
			case 0xfe:
				decoded.check_order_reply = readOnlyCommand(bytes, counterObj, 1);
				break;
			case 0xef:
				decoded.ans = decoded.ans || [];
				var ans_item = {};
				var bitOptions = readUInt8(bytes, counterObj, 1);
				// 0：success, 1：unknow, 2：error order, 3：error passwd, 4：error read params, 5：error write params, 6：error read, 7：error write, 8：error read apply, 9：error write apply
				ans_item.result = extractBits(bitOptions, 4, 8);
				ans_item.length = extractBits(bitOptions, 0, 4);
				ans_item.id = readCommand(bytes, counterObj, ans_item.length);
				decoded.ans.push(ans_item);
				break;
			case 0xee:
				decoded.all_configurations_request_by_device = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xed:
				if (history.length === 0) {
					for (var k in decoded) {
						if (decoded.hasOwnProperty(k)) {
							result[k] = decoded[k];
						}
					}
				}
				decoded = {};
				// skip type
				readUInt8(bytes, counterObj, 1);
				decoded.timestamp = readUInt32LE(bytes, counterObj, 4);
				history.push(decoded);
				break;
			case 0xcf:
				// skip 1 byte
				counterObj.i++;
				decoded.lorawan_class = readLoRaWANClass(readUInt8(bytes, counterObj, 1));
				break;
			case 0xdf:
				decoded.tsl_version = readProtocolVersion(readBytes(bytes, counterObj, 2));
				break;
			case 0xde:
				decoded.product_name = readString(bytes, counterObj, 32);
				break;
			case 0xdd:
				decoded.product_pn = readString(bytes, counterObj, 32);
				break;
			case 0xdb:
				decoded.product_sn = readHexString(bytes, counterObj, 8);
				break;
			case 0xda:
				decoded.version = decoded.version || {};
				decoded.version.hardware_version = readHardwareVersion(readBytes(bytes, counterObj, 2));
				decoded.version.firmware_version = readFirmwareVersion(readBytes(bytes, counterObj, 6));
				break;
			case 0xd9:
				decoded.oem_id = readHexString(bytes, counterObj, 2);
				break;
			case 0xc8:
				// 0：Off, 1：On
				decoded.device_status = readUInt8(bytes, counterObj, 1);
				break;
			case 0xd8:
				decoded.product_frequency_band = readString(bytes, counterObj, 16);
				break;
			case 0x00:
				decoded.battery = readUInt8(bytes, counterObj, 1);
				break;
			case 0x01:
				decoded.temperature = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x02:
				decoded.motor_total_stroke = readUInt16LE(bytes, counterObj, 2);
				break;
			case 0x03:
				decoded.motor_position = readUInt16LE(bytes, counterObj, 2);
				break;
			case 0x04:
				decoded.valve_opening_degree = readUInt8(bytes, counterObj, 1);
				break;
			case 0x05:
				decoded.motor_calibration_result_report = decoded.motor_calibration_result_report || {};
				// 0：Uncalibrated, 1：Calibration success, 2：Calibration failed,out of range , 3：Calibration failed,temperature control disabled, 4：Calibration failed,uninstalled
				decoded.motor_calibration_result_report.status = readUInt8(bytes, counterObj, 1);
				break;
			case 0x06:
				decoded.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x07:
				decoded.target_valve_opening_degree = readUInt8(bytes, counterObj, 1);
				break;
			case 0x08:
				decoded.low_battery_alarm = decoded.low_battery_alarm || {};
				decoded.low_battery_alarm.value = readUInt8(bytes, counterObj, 1);
				decoded.battery = decoded.low_battery_alarm.value;
				break;
			case 0x09:
				decoded.temperature_alarm = decoded.temperature_alarm || {};
				decoded.temperature_alarm.type = readUInt8(bytes, counterObj, 1);
				if (decoded.temperature_alarm.type == 0x10) {
					decoded.temperature_alarm.lower_range_alarm_deactivation = decoded.temperature_alarm.lower_range_alarm_deactivation || {};
					decoded.temperature_alarm.lower_range_alarm_deactivation.temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.temperature_alarm.lower_range_alarm_deactivation.temperature;
				}
				if (decoded.temperature_alarm.type == 0x11) {
					decoded.temperature_alarm.lower_range_alarm_trigger = decoded.temperature_alarm.lower_range_alarm_trigger || {};
					decoded.temperature_alarm.lower_range_alarm_trigger.temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.temperature_alarm.lower_range_alarm_trigger.temperature;
				}
				if (decoded.temperature_alarm.type == 0x12) {
					decoded.temperature_alarm.over_range_alarm_deactivation = decoded.temperature_alarm.over_range_alarm_deactivation || {};
					decoded.temperature_alarm.over_range_alarm_deactivation.temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.temperature_alarm.over_range_alarm_deactivation.temperature;
				}
				if (decoded.temperature_alarm.type == 0x13) {
					decoded.temperature_alarm.over_range_alarm_trigger = decoded.temperature_alarm.over_range_alarm_trigger || {};
					decoded.temperature_alarm.over_range_alarm_trigger.temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.temperature_alarm.over_range_alarm_trigger.temperature;
				}
				break;
			case 0x0a:
				decoded.anti_freeze_protection_alarm = decoded.anti_freeze_protection_alarm || {};
				decoded.anti_freeze_protection_alarm.type = readUInt8(bytes, counterObj, 1);
				if (decoded.anti_freeze_protection_alarm.type == 0x20) {
					decoded.anti_freeze_protection_alarm.lifted = decoded.anti_freeze_protection_alarm.lifted || {};
					decoded.anti_freeze_protection_alarm.lifted.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.anti_freeze_protection_alarm.lifted.environment_temperature;
					decoded.anti_freeze_protection_alarm.lifted.current_valve_status = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.anti_freeze_protection_alarm.lifted.current_valve_status;
				}
				if (decoded.anti_freeze_protection_alarm.type == 0x21) {
					decoded.anti_freeze_protection_alarm.trigger = decoded.anti_freeze_protection_alarm.trigger || {};
					decoded.anti_freeze_protection_alarm.trigger.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.anti_freeze_protection_alarm.trigger.environment_temperature;
					decoded.anti_freeze_protection_alarm.trigger.current_valve_status = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.anti_freeze_protection_alarm.trigger.current_valve_status;
				}
				break;
			case 0x0b:
				decoded.mandatory_heating_alarm = decoded.mandatory_heating_alarm || {};
				decoded.mandatory_heating_alarm.type = readUInt8(bytes, counterObj, 1);
				if (decoded.mandatory_heating_alarm.type == 0x20) {
					decoded.mandatory_heating_alarm.exit = decoded.mandatory_heating_alarm.exit || {};
					decoded.mandatory_heating_alarm.exit.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.mandatory_heating_alarm.exit.environment_temperature;
					decoded.mandatory_heating_alarm.exit.current_valve_status = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.mandatory_heating_alarm.exit.current_valve_status;
					decoded.mandatory_heating_alarm.exit.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.mandatory_heating_alarm.exit.battery_level;
				}
				if (decoded.mandatory_heating_alarm.type == 0x21) {
					decoded.mandatory_heating_alarm.enter = decoded.mandatory_heating_alarm.enter || {};
					decoded.mandatory_heating_alarm.enter.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.mandatory_heating_alarm.enter.environment_temperature;
					decoded.mandatory_heating_alarm.enter.current_valve_status = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.mandatory_heating_alarm.enter.current_valve_status;
					decoded.mandatory_heating_alarm.enter.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.mandatory_heating_alarm.enter.battery_level;
				}
				break;
			case 0x0c:
				decoded.auto_away_report = decoded.auto_away_report || {};
				decoded.auto_away_report.event_type = readUInt8(bytes, counterObj, 1);
				if (decoded.auto_away_report.event_type == 0x20) {
					decoded.auto_away_report.inactive_by_target_temperature = decoded.auto_away_report.inactive_by_target_temperature || {};
					// 0：Unoccupied, 1：Occupied
					decoded.auto_away_report.inactive_by_target_temperature.state = readUInt8(bytes, counterObj, 1);
					decoded.auto_away_report.inactive_by_target_temperature.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.auto_away_report.inactive_by_target_temperature.environment_temperature;
					decoded.auto_away_report.inactive_by_target_temperature.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.target_temperature = decoded.auto_away_report.inactive_by_target_temperature.target_temperature;
				}
				if (decoded.auto_away_report.event_type == 0x21) {
					decoded.auto_away_report.active_by_target_temperature = decoded.auto_away_report.active_by_target_temperature || {};
					// 0：Unoccupied, 1：Occupied
					decoded.auto_away_report.active_by_target_temperature.state = readUInt8(bytes, counterObj, 1);
					decoded.auto_away_report.active_by_target_temperature.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.auto_away_report.active_by_target_temperature.environment_temperature;
					decoded.auto_away_report.active_by_target_temperature.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (decoded.auto_away_report.event_type == 0x22) {
					decoded.auto_away_report.inactive_by_target_valve_opening = decoded.auto_away_report.inactive_by_target_valve_opening || {};
					// 0：Unoccupied, 1：Occupied
					decoded.auto_away_report.inactive_by_target_valve_opening.state = readUInt8(bytes, counterObj, 1);
					decoded.auto_away_report.inactive_by_target_valve_opening.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.auto_away_report.inactive_by_target_valve_opening.environment_temperature;
					decoded.auto_away_report.inactive_by_target_valve_opening.target_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.target_valve_opening_degree = decoded.auto_away_report.inactive_by_target_valve_opening.target_valve_opening;
				}
				if (decoded.auto_away_report.event_type == 0x23) {
					decoded.auto_away_report.active_by_target_valve_opening = decoded.auto_away_report.active_by_target_valve_opening || {};
					// 0：Unoccupied, 1：Occupied
					decoded.auto_away_report.active_by_target_valve_opening.state = readUInt8(bytes, counterObj, 1);
					decoded.auto_away_report.active_by_target_valve_opening.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.auto_away_report.active_by_target_valve_opening.environment_temperature;
					decoded.auto_away_report.active_by_target_valve_opening.target_valve_opening = readUInt8(bytes, counterObj, 1);
				}
				break;
			case 0x0d:
				decoded.window_opening_alarm = decoded.window_opening_alarm || {};
				decoded.window_opening_alarm.type = readUInt8(bytes, counterObj, 1);
				if (decoded.window_opening_alarm.type == 0x20) {
					decoded.window_opening_alarm.release = decoded.window_opening_alarm.release || {};
					// 0：Normal, 1：Open
					decoded.window_opening_alarm.release.state = readUInt8(bytes, counterObj, 1);
					decoded.window_opening_alarm.release.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.window_opening_alarm.release.environment_temperature;
				}
				if (decoded.window_opening_alarm.type == 0x21) {
					decoded.window_opening_alarm.trigger = decoded.window_opening_alarm.trigger || {};
					// 0：Normal, 1：Open
					decoded.window_opening_alarm.trigger.state = readUInt8(bytes, counterObj, 1);
					decoded.window_opening_alarm.trigger.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.window_opening_alarm.trigger.environment_temperature;
				}
				break;
			case 0x0e:
				decoded.periodic_reporting = decoded.periodic_reporting || {};
				decoded.periodic_reporting.report_type = readUInt8(bytes, counterObj, 1);
				if (decoded.periodic_reporting.report_type == 0x00) {
					decoded.periodic_reporting.non_heating_season = decoded.periodic_reporting.non_heating_season || {};
					decoded.periodic_reporting.non_heating_season.target_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.target_valve_opening_degree = decoded.periodic_reporting.non_heating_season.target_valve_opening;
					decoded.periodic_reporting.non_heating_season.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.periodic_reporting.non_heating_season.battery_level;
				}
				if (decoded.periodic_reporting.report_type == 0x01) {
					decoded.periodic_reporting.target_temperature_for_heating = decoded.periodic_reporting.target_temperature_for_heating || {};
					decoded.periodic_reporting.target_temperature_for_heating.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.periodic_reporting.target_temperature_for_heating.environment_temperature;
					decoded.periodic_reporting.target_temperature_for_heating.current_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.periodic_reporting.target_temperature_for_heating.current_valve_opening;
					decoded.periodic_reporting.target_temperature_for_heating.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.target_temperature = decoded.periodic_reporting.target_temperature_for_heating.target_temperature;
					decoded.periodic_reporting.target_temperature_for_heating.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.periodic_reporting.target_temperature_for_heating.battery_level;
				}
				if (decoded.periodic_reporting.report_type == 0x02) {
					decoded.periodic_reporting.target_valve_opening_for_heating = decoded.periodic_reporting.target_valve_opening_for_heating || {};
					decoded.periodic_reporting.target_valve_opening_for_heating.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.periodic_reporting.target_valve_opening_for_heating.environment_temperature;
					decoded.periodic_reporting.target_valve_opening_for_heating.current_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.periodic_reporting.target_valve_opening_for_heating.current_valve_opening;
					decoded.periodic_reporting.target_valve_opening_for_heating.target_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.target_valve_opening_degree = decoded.periodic_reporting.target_valve_opening_for_heating.target_valve_opening;
					decoded.periodic_reporting.target_valve_opening_for_heating.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.periodic_reporting.target_valve_opening_for_heating.battery_level;
				}
				if (decoded.periodic_reporting.report_type == 0x03) {
					decoded.periodic_reporting.integrated_control_for_heating = decoded.periodic_reporting.integrated_control_for_heating || {};
					decoded.periodic_reporting.integrated_control_for_heating.environment_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.temperature = decoded.periodic_reporting.integrated_control_for_heating.environment_temperature;
					decoded.periodic_reporting.integrated_control_for_heating.current_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.valve_opening_degree = decoded.periodic_reporting.integrated_control_for_heating.current_valve_opening;
					decoded.periodic_reporting.integrated_control_for_heating.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					decoded.target_temperature = decoded.periodic_reporting.integrated_control_for_heating.target_temperature;
					decoded.periodic_reporting.integrated_control_for_heating.target_valve_opening = readUInt8(bytes, counterObj, 1);
					decoded.target_valve_opening_degree = decoded.periodic_reporting.integrated_control_for_heating.target_valve_opening;
					decoded.periodic_reporting.integrated_control_for_heating.battery_level = readUInt8(bytes, counterObj, 1);
					decoded.battery = decoded.periodic_reporting.integrated_control_for_heating.battery_level;
				}
				break;
			case 0xc9:
				// 0：Disable, 1：Enable
				decoded.random_key = readUInt8(bytes, counterObj, 1);
				break;
			case 0xc4:
				// 0：Disable, 1：Enable
				decoded.auto_p_enable = readUInt8(bytes, counterObj, 1);
				break;
			case 0x60:
				// 0：℃, 1：℉
				decoded.temperature_unit = readUInt8(bytes, counterObj, 1);
				break;
			case 0x61:
				decoded.temperature_source_settings = decoded.temperature_source_settings || {};
				// 0：Internal NTC, 1：External NTC, 2：LoRa Receive
				decoded.temperature_source_settings.type = readUInt8(bytes, counterObj, 1);
				if (decoded.temperature_source_settings.type == 0x01) {
					decoded.temperature_source_settings.external_ntc_reception = decoded.temperature_source_settings.external_ntc_reception || {};
					decoded.temperature_source_settings.external_ntc_reception.timeout = readUInt16LE(bytes, counterObj, 2);
					// 0: Maintaining State Control, 1: Close the Valve, 2: Switch to Internal NTC Control
					decoded.temperature_source_settings.external_ntc_reception.timeout_response = readUInt8(bytes, counterObj, 1);
				}
				if (decoded.temperature_source_settings.type == 0x02) {
					decoded.temperature_source_settings.lorawan_reception = decoded.temperature_source_settings.lorawan_reception || {};
					decoded.temperature_source_settings.lorawan_reception.timeout = readUInt16LE(bytes, counterObj, 2);
					// 0: Maintaining State Control, 1: Close the Valve, 2: Switch to Internal NTC Control
					decoded.temperature_source_settings.lorawan_reception.timeout_response = readUInt8(bytes, counterObj, 1);
				}
				break;
			case 0x62:
				// 0：Disable, 1：Enable
				decoded.environment_temperature_display_enable = readUInt8(bytes, counterObj, 1);
				break;
			case 0x63:
				decoded.heating_period_settings = decoded.heating_period_settings || {};
				var heating_period_settings_command = readUInt8(bytes, counterObj, 1);
				if (heating_period_settings_command == 0x00) {
					decoded.heating_period_settings.heating_date_settings = decoded.heating_period_settings.heating_date_settings || {};
					decoded.heating_period_settings.heating_date_settings.start_mon = readUInt8(bytes, counterObj, 1);
					decoded.heating_period_settings.heating_date_settings.start_day = readUInt8(bytes, counterObj, 1);
					decoded.heating_period_settings.heating_date_settings.end_mon = readUInt8(bytes, counterObj, 1);
					decoded.heating_period_settings.heating_date_settings.end_day = readUInt8(bytes, counterObj, 1);
				}
				if (heating_period_settings_command == 0x01) {
					decoded.heating_period_settings.heating_period_reporting_interval = decoded.heating_period_settings.heating_period_reporting_interval || {};
					// 0：second, 1：min
					decoded.heating_period_settings.heating_period_reporting_interval.unit = readUInt8(bytes, counterObj, 1);
					if (decoded.heating_period_settings.heating_period_reporting_interval.unit == 0x00) {
						decoded.heating_period_settings.heating_period_reporting_interval.seconds_of_time = readUInt16LE(bytes, counterObj, 2);
					}
					if (decoded.heating_period_settings.heating_period_reporting_interval.unit == 0x01) {
						decoded.heating_period_settings.heating_period_reporting_interval.minutes_of_time = readUInt16LE(bytes, counterObj, 2);
					}
				}
				if (heating_period_settings_command == 0x02) {
					decoded.heating_period_settings.non_heating_period_reporting_interval = decoded.heating_period_settings.non_heating_period_reporting_interval || {};
					// 0：second, 1：min
					decoded.heating_period_settings.non_heating_period_reporting_interval.unit = readUInt8(bytes, counterObj, 1);
					if (decoded.heating_period_settings.non_heating_period_reporting_interval.unit == 0x00) {
						decoded.heating_period_settings.non_heating_period_reporting_interval.seconds_of_time = readUInt16LE(bytes, counterObj, 2);
					}
					if (decoded.heating_period_settings.non_heating_period_reporting_interval.unit == 0x01) {
						decoded.heating_period_settings.non_heating_period_reporting_interval.minutes_of_time = readUInt16LE(bytes, counterObj, 2);
					}
				}
				if (heating_period_settings_command == 0x03) {
					// 0：Fully Close, 1：Fully Open
					decoded.heating_period_settings.valve_status_control = readUInt8(bytes, counterObj, 1);
				}
				break;
			case 0x65:
				decoded.temp_control = decoded.temp_control || {};
				var temp_control_command = readUInt8(bytes, counterObj, 1);
				if (temp_control_command == 0x00) {
					// 0：Disable, 1：Enable
					decoded.temp_control.enable = readUInt8(bytes, counterObj, 1);
				}
				if (temp_control_command == 0x01) {
					// 0：0.5, 1：1
					decoded.temp_control.target_temperature_resolution = readUInt8(bytes, counterObj, 1);
				}
				if (temp_control_command == 0x02) {
					decoded.temp_control.under_temperature_side_deadband = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (temp_control_command == 0x03) {
					decoded.temp_control.over_temperature_side_deadband = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (temp_control_command == 0x04) {
					decoded.temp_control.target_temperature_adjustment_range_min = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (temp_control_command == 0x05) {
					decoded.temp_control.target_temperature_adjustment_range_max = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (temp_control_command == 0x06) {
					decoded.temp_control.mode_settings = decoded.temp_control.mode_settings || {};
					// 0：Automatic Temperature Control, 1：Valve Opening Control, 2：Integrated Control
					decoded.temp_control.mode_settings.mode = readUInt8(bytes, counterObj, 1);
					if (decoded.temp_control.mode_settings.mode == 0x00) {
						decoded.temp_control.mode_settings.auto_control = decoded.temp_control.mode_settings.auto_control || {};
						decoded.temp_control.mode_settings.auto_control.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
					}
					if (decoded.temp_control.mode_settings.mode == 0x01) {
						decoded.temp_control.mode_settings.valve_control = decoded.temp_control.mode_settings.valve_control || {};
						decoded.temp_control.mode_settings.valve_control.target_valve_status = readUInt8(bytes, counterObj, 1);
					}
					if (decoded.temp_control.mode_settings.mode == 0x02) {
						decoded.temp_control.mode_settings.intergrated_control = decoded.temp_control.mode_settings.intergrated_control || {};
						decoded.temp_control.mode_settings.intergrated_control.target_temp = readInt16LE(bytes, counterObj, 2) / 100;
					}
				}
				break;
			case 0x66:
				decoded.window_opening_detection_settings = decoded.window_opening_detection_settings || {};
				// 0：Disable, 1：Enable
				decoded.window_opening_detection_settings.enable = readUInt8(bytes, counterObj, 1);
				decoded.window_opening_detection_settings.cooling_rate = readInt16LE(bytes, counterObj, 2) / 100;
				// 0：Remains Unchanged, 1：Close the Valve
				decoded.window_opening_detection_settings.valve_status = readUInt8(bytes, counterObj, 1);
				decoded.window_opening_detection_settings.stop_temperature_control_time = readUInt16LE(bytes, counterObj, 2);
				break;
			case 0x67:
				decoded.auto_away_settings = decoded.auto_away_settings || {};
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.enable = readUInt8(bytes, counterObj, 1);
				decoded.auto_away_settings.start_time = readUInt16LE(bytes, counterObj, 2);
				decoded.auto_away_settings.end_time = readUInt16LE(bytes, counterObj, 2);
				var bitOptions = readUInt8(bytes, counterObj, 1);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_sun = extractBits(bitOptions, 0, 1);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_mon = extractBits(bitOptions, 1, 2);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_tues = extractBits(bitOptions, 2, 3);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_wed = extractBits(bitOptions, 3, 4);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_thur = extractBits(bitOptions, 4, 5);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_fri = extractBits(bitOptions, 5, 6);
				// 0：Disable, 1：Enable
				decoded.auto_away_settings.cycle_time_sat = extractBits(bitOptions, 6, 7);
				decoded.auto_away_settings.reserved = extractBits(bitOptions, 7, 8);
				decoded.auto_away_settings.energy_saving_settings = decoded.auto_away_settings.energy_saving_settings || {};
				// 0：Energy Saving Temperature, 1：Energy Saving Valve Opening
				decoded.auto_away_settings.energy_saving_settings.mode = readUInt8(bytes, counterObj, 1);
				if (decoded.auto_away_settings.energy_saving_settings.mode == 0x00) {
					decoded.auto_away_settings.energy_saving_settings.energy_saving_temperature = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (decoded.auto_away_settings.energy_saving_settings.mode == 0x01) {
					decoded.auto_away_settings.energy_saving_settings.energy_saving_valve_opening_degree = readUInt8(bytes, counterObj, 1);
				}
				break;
			case 0x68:
				decoded.anti_freeze_protection_setting = decoded.anti_freeze_protection_setting || {};
				// 0：Disable, 1：Enable
				decoded.anti_freeze_protection_setting.enable = readUInt8(bytes, counterObj, 1);
				decoded.anti_freeze_protection_setting.temperature_value = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x69:
				// 0：Disable, 1：Enable
				decoded.mandatory_heating_enable = readUInt8(bytes, counterObj, 1);
				break;
			case 0x6a:
				decoded.child_lock = decoded.child_lock || {};
				// 0：Disable, 1：Enable
				decoded.child_lock.enable = readUInt8(bytes, counterObj, 1);
				var bitOptions = readUInt8(bytes, counterObj, 1);
				// 0：Disable, 1：Enable
				decoded.child_lock.system_button = extractBits(bitOptions, 0, 1);
				// 0：Disable, 1：Enable
				decoded.child_lock.func_button = extractBits(bitOptions, 1, 2);
				decoded.child_lock.reserved = extractBits(bitOptions, 2, 8);
				break;
			case 0x6b:
				decoded.motor_stroke_limit = readUInt8(bytes, counterObj, 1);
				break;
			case 0x6c:
				decoded.temperature_calibration_settings = decoded.temperature_calibration_settings || {};
				// 0：Disable, 1：Enable
				decoded.temperature_calibration_settings.enable = readUInt8(bytes, counterObj, 1);
				decoded.temperature_calibration_settings.calibration_value = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x6d:
				decoded.temperature_alarm_settings = decoded.temperature_alarm_settings || {};
				// 0：Disable, 1：Enable
				decoded.temperature_alarm_settings.enable = readUInt8(bytes, counterObj, 1);
				// 0:Disable, 1:Condition: x<A, 2:Condition: x>B, 4:Condition: x<A or x>B
				decoded.temperature_alarm_settings.threshold_condition = readUInt8(bytes, counterObj, 1);
				decoded.temperature_alarm_settings.threshold_min = readInt16LE(bytes, counterObj, 2) / 100;
				decoded.temperature_alarm_settings.threshold_max = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x6e:
				decoded.schedule_settings = decoded.schedule_settings || [];
				var id = readUInt8(bytes, counterObj, 1);
				var schedule_settings_item = pickArrayItem(decoded.schedule_settings, id, 'id');
				schedule_settings_item.id = id;
				insertArrayItem(decoded.schedule_settings, schedule_settings_item, 'id');
				var schedule_settings_item_command = readUInt8(bytes, counterObj, 1);
				if (schedule_settings_item_command == 0x00) {
					// 0：Disable, 1：Enable
					schedule_settings_item.enable = readUInt8(bytes, counterObj, 1);
				}
				if (schedule_settings_item_command == 0x01) {
					schedule_settings_item.start_time = readUInt16LE(bytes, counterObj, 2);
				}
				if (schedule_settings_item_command == 0x02) {
					schedule_settings_item.cycle_settings = schedule_settings_item.cycle_settings || {};
					var bitOptions = readUInt8(bytes, counterObj, 1);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_sun = extractBits(bitOptions, 0, 1);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_mon = extractBits(bitOptions, 1, 2);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_tues = extractBits(bitOptions, 2, 3);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_wed = extractBits(bitOptions, 3, 4);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_thur = extractBits(bitOptions, 4, 5);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_fri = extractBits(bitOptions, 5, 6);
					// 0：Disable, 1：Enable
					schedule_settings_item.cycle_settings.execution_day_sat = extractBits(bitOptions, 6, 7);
					schedule_settings_item.cycle_settings.reserved = extractBits(bitOptions, 7, 8);
				}
				if (schedule_settings_item_command == 0x03) {
					// 0：Automatic Temperature Control, 1：Valve Opening Control, 2：Integrated Control
					schedule_settings_item.temperature_control_mode = readUInt8(bytes, counterObj, 1);
				}
				if (schedule_settings_item_command == 0x04) {
					schedule_settings_item.target_temperature = readInt16LE(bytes, counterObj, 2) / 100;
				}
				if (schedule_settings_item_command == 0x05) {
					schedule_settings_item.target_valve_status = readUInt8(bytes, counterObj, 1);
				}
				if (schedule_settings_item_command == 0x06) {
					// 0：Disable, 1：Enable
					schedule_settings_item.pre_heating_enable = readUInt8(bytes, counterObj, 1);
				}
				if (schedule_settings_item_command == 0x07) {
					// 0：Auto, 1：Manual
					schedule_settings_item.pre_heating_mode = readUInt8(bytes, counterObj, 1);
				}
				if (schedule_settings_item_command == 0x08) {
					schedule_settings_item.pre_heating_manual_time = readUInt16LE(bytes, counterObj, 2);
				}
				if (schedule_settings_item_command == 0x09) {
					schedule_settings_item.report_cycle = readUInt16LE(bytes, counterObj, 2);
				}
				break;
			case 0x6f:
				// 0：Disable, 1：Enable
				decoded.change_report_enable = readUInt8(bytes, counterObj, 1);
				break;
			case 0x70:
				decoded.motor_controllable_range = decoded.motor_controllable_range || {};
				// 0：Disable, 1：Enable
				decoded.motor_controllable_range.enable = readUInt8(bytes, counterObj, 1);
				decoded.motor_controllable_range.distance = readUInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0xc7:
				decoded.time_zone = readInt16LE(bytes, counterObj, 2);
				break;
			case 0xc6:
				decoded.daylight_saving_time = decoded.daylight_saving_time || {};
				// 0：Disable, 1：Enable
				decoded.daylight_saving_time.enable = readUInt8(bytes, counterObj, 1);
				decoded.daylight_saving_time.daylight_saving_time_offset = readUInt8(bytes, counterObj, 1);
				// 1:Jan., 2:Feb., 3:Mar., 4:Apr., 5:May, 6:Jun., 7:Jul., 8:Aug., 9:Sep., 10:Oct., 11:Nov., 12:Dec.
				decoded.daylight_saving_time.start_month = readUInt8(bytes, counterObj, 1);
				var bitOptions = readUInt8(bytes, counterObj, 1);
				// 1:1st, 2: 2nd, 3: 3rd, 4: 4th, 5: last
				decoded.daylight_saving_time.start_week_num = extractBits(bitOptions, 4, 8);
				// 1：Mon., 2：Tues., 3：Wed., 4：Thurs., 5：Fri., 6：Sat., 7：Sun.
				decoded.daylight_saving_time.start_week_day = extractBits(bitOptions, 0, 4);
				decoded.daylight_saving_time.start_hour_min = readUInt16LE(bytes, counterObj, 2);
				// 1:Jan., 2:Feb., 3:Mar., 4:Apr., 5:May, 6:Jun., 7:Jul., 8:Aug., 9:Sep., 10:Oct., 11:Nov., 12:Dec.
				decoded.daylight_saving_time.end_month = readUInt8(bytes, counterObj, 1);
				var bitOptions = readUInt8(bytes, counterObj, 1);
				// 1:1st, 2: 2nd, 3: 3rd, 4: 4th, 5: last
				decoded.daylight_saving_time.end_week_num = extractBits(bitOptions, 4, 8);
				// 1：Mon., 2：Tues., 3：Wed., 4：Thurs., 5：Fri., 6：Sat., 7：Sun.
				decoded.daylight_saving_time.end_week_day = extractBits(bitOptions, 0, 4);
				decoded.daylight_saving_time.end_hour_min = readUInt16LE(bytes, counterObj, 2);
				break;
			case 0xc5:
				decoded.data_storage_settings = decoded.data_storage_settings || {};
				var data_storage_settings_command = readUInt8(bytes, counterObj, 1);
				if (data_storage_settings_command == 0x00) {
					// 0：Disable, 1：Enable
					decoded.data_storage_settings.enable = readUInt8(bytes, counterObj, 1);
				}
				if (data_storage_settings_command == 0x01) {
					// 0：Disable, 1：Enable
					decoded.data_storage_settings.retransmission_enable = readUInt8(bytes, counterObj, 1);
				}
				if (data_storage_settings_command == 0x02) {
					decoded.data_storage_settings.retransmission_interval = readUInt16LE(bytes, counterObj, 2);
				}
				if (data_storage_settings_command == 0x03) {
					decoded.data_storage_settings.retrieval_interval = readUInt16LE(bytes, counterObj, 2);
				}
				break;
			case 0xb6:
				decoded.reconnect = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xb9:
				decoded.query_device_status = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xb8:
				decoded.synchronize_time = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xb7:
				decoded.set_time = decoded.set_time || {};
				decoded.set_time.timestamp = readUInt32LE(bytes, counterObj, 4);
				break;
			case 0xb5:
				decoded.collect_data = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xbd:
				decoded.clear_historical_data = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xbc:
				decoded.stop_historical_data_retrieval = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xbb:
				decoded.retrieve_historical_data_by_time_range = decoded.retrieve_historical_data_by_time_range || {};
				decoded.retrieve_historical_data_by_time_range.start_time = readUInt32LE(bytes, counterObj, 4);
				decoded.retrieve_historical_data_by_time_range.end_time = readUInt32LE(bytes, counterObj, 4);
				break;
			case 0xba:
				decoded.retrieve_historical_data_by_time = decoded.retrieve_historical_data_by_time || {};
				decoded.retrieve_historical_data_by_time.time = readUInt32LE(bytes, counterObj, 4);
				break;
			case 0x57:
				decoded.query_motor_stroke_position = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0x58:
				decoded.calibrate_motor = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0x59:
				decoded.set_target_valve_opening_degree = decoded.set_target_valve_opening_degree || {};
				decoded.set_target_valve_opening_degree.value = readUInt8(bytes, counterObj, 1);
				break;
			case 0x5a:
				decoded.set_target_temperature = decoded.set_target_temperature || {};
				decoded.set_target_temperature.value = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x5b:
				decoded.set_temperature = decoded.set_temperature || {};
				decoded.set_temperature.value = readInt16LE(bytes, counterObj, 2) / 100;
				break;
			case 0x5c:
				decoded.set_occupancy_state = decoded.set_occupancy_state || {};
				// 0：Unoccupied, 1：Occupied
				decoded.set_occupancy_state.state = readUInt8(bytes, counterObj, 1);
				break;
			case 0x5d:
				decoded.set_opening_window = decoded.set_opening_window || {};
				// 0：Normal, 1：Open
				decoded.set_opening_window.state = readUInt8(bytes, counterObj, 1);
				break;
			case 0x5e:
				decoded.delete_schedule = decoded.delete_schedule || {};
				// 0：Schedule1, 1：Schedule2, 2：Schedule3, 3：Schedule4, 4：Schedule5, 5：Schedule6, 6：Schedule7, 7：Schedule8, 8：Schedule9, 9：Schedule10, 10：Schedule11, 11：Schedule12, 12：Schedule13, 13：Schedule14, 14：Schedule15, 15：Schedule16, 255：Reset All 
				decoded.delete_schedule.type = readUInt8(bytes, counterObj, 1);
				break;
			case 0xbf:
				decoded.reset = readOnlyCommand(bytes, counterObj, 0);
				break;
			case 0xbe:
				decoded.reboot = readOnlyCommand(bytes, counterObj, 0);
				break;
			default:
				unknown_command = 1;
				break;
		}
		if (unknown_command) {
			throw new Error('unknown command: ' + command_id);
		}
	}

	if (Object.keys(history).length > 0) {
		result.history = history;
	} else {        
		for (var k2 in decoded) {
			if (decoded.hasOwnProperty(k2)) {
				result[k2] = decoded[k2];
			}
		}
	}

	processTemperature(result);

	return result;
}

function readOnlyCommand(bytes, counterObj, end) {
	counterObj.i += end;
	return 1;
}

function readUnknownDataType(allBytes, counterObj, end) {
	throw new Error('Unknown data type encountered. Please Contact Developer.');
}

function readBytes(allBytes, counterObj, end) {
	var bytes = allBytes.slice(counterObj.i, counterObj.i + end);
	counterObj.i += end;
	return bytes;
}

function readProtocolVersion(bytes) {
	var major = bytes[0] & 0xff;
	var minor = bytes[1] & 0xff;
	return 'v' + major + '.' + minor;
}

function readLoRaWANClass(type) {
	var lorawan_class_map = {
		0: "Class A",
		1: "Class B",
		2: "Class C",
		3: "Class CtoB",
	};
	return lorawan_class_map[type] || "Unknown";
}

function readHardwareVersion(bytes) {
	var major = bytes[0] & 0xff;
	var minor = bytes[1] & 0xff;
	return 'v' + major + '.' + minor;
}

function readFirmwareVersion(bytes) {
	var major = (bytes[0] & 0xff).toString(16);
	var minor = (bytes[1] & 0xff).toString(16);
	var release = (bytes[2] & 0xff).toString(16);
	var alpha = (bytes[3] & 0xff).toString(16);
	var unit_test = (bytes[4] & 0xff).toString(16);
	var test = (bytes[5] & 0xff).toString(16);

	var version = 'v' + major + '.' + minor;
	if (release !== '0') version += '-r' + release;
	if (alpha !== '0') version += '-a' + alpha;
	if (unit_test !== '0') version += '-u' + unit_test;
	if (test !== '0') version += '-t' + test;
	return version;
}

/* eslint-disable */
function readUInt8(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	return bytes[0] & 0xff;
}

function readInt8(allBytes, counterObj, end) {
	var ref = readUInt8(allBytes, counterObj, end);
	return ref > 0x7f ? ref - 0x100 : ref;
}

function readUInt16LE(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	var value = (bytes[1] << 8) + bytes[0];
	return value & 0xffff;
}

function readInt16LE(allBytes, counterObj, end) {
	var ref = readUInt16LE(allBytes, counterObj, end);
	return ref > 0x7fff ? ref - 0x10000 : ref;
}

function readUInt24LE(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end); // 3 bytes expected
	var value = (bytes[2] << 16) + (bytes[1] << 8) + bytes[0];
	return value & 0xffffff;
}

function readInt24LE(allBytes, counterObj, end) {
	var ref = readUInt24LE(allBytes, counterObj, end);
	return ref > 0x7fffff ? ref - 0x1000000 : ref;
}

function readUInt32LE(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	var value = (bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + bytes[0];
	return (value & 0xffffffff) >>> 0;
}

function readInt32LE(allBytes, counterObj, end) {
	var ref = readUInt32LE(allBytes, counterObj, end);
	return ref > 0x7fffffff ? ref - 0x100000000 : ref;
}

function readFloat16LE(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	var bits = (bytes[1] << 8) | bytes[0];
	var sign = bits >>> 15 === 0 ? 1.0 : -1.0;
	var e = (bits >>> 10) & 0x1f;
	var m = e === 0 ? (bits & 0x3ff) << 1 : (bits & 0x3ff) | 0x400;
	var f = sign * m * Math.pow(2, e - 25);

	var n = Number(f.toFixed(2));
	return n;
}

function readFloatLE(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	var bits = (bytes[3] << 24) | (bytes[2] << 16) | (bytes[1] << 8) | bytes[0];
	var sign = bits >>> 31 === 0 ? 1.0 : -1.0;
	var e = (bits >>> 23) & 0xff;
	var m = e === 0 ? (bits & 0x7fffff) << 1 : (bits & 0x7fffff) | 0x800000;
	var f = sign * m * Math.pow(2, e - 150);
	return f;
}

function readString(allBytes, counterObj, end) {
	var str = "";
	var bytes = readBytes(allBytes, counterObj, end);
	var i = 0;
	var byte1, byte2, byte3, byte4;
	while (i < bytes.length) {
		byte1 = bytes[i++];
		if (byte1 <= 0x7f) {
			str += String.fromCharCode(byte1);
		} else if (byte1 <= 0xdf) {
			byte2 = bytes[i++];
			str += String.fromCharCode(((byte1 & 0x1f) << 6) | (byte2 & 0x3f));
		} else if (byte1 <= 0xef) {
			byte2 = bytes[i++];
			byte3 = bytes[i++];
			str += String.fromCharCode(((byte1 & 0x0f) << 12) | ((byte2 & 0x3f) << 6) | (byte3 & 0x3f));
		} else if (byte1 <= 0xf7) {
			byte2 = bytes[i++];
			byte3 = bytes[i++];
			byte4 = bytes[i++];
			var codepoint = ((byte1 & 0x07) << 18) | ((byte2 & 0x3f) << 12) | ((byte3 & 0x3f) << 6) | (byte4 & 0x3f);
			codepoint -= 0x10000;
			str += String.fromCharCode((codepoint >> 10) + 0xd800);
			str += String.fromCharCode((codepoint & 0x3ff) + 0xdc00);
		}
	}
	return str.replace(/\u0000+$/g, '');
}

function readHexString(allBytes, counterObj, end) {
	var temp = [];
	var bytes = readBytes(allBytes, counterObj, end);
	for (var idx = 0; idx < bytes.length; idx++) {
		temp.push(("0" + (bytes[idx] & 0xff).toString(16)).slice(-2));
	}
	return temp.join("").replace(/\u0000+$/g, '');
}

function readHexStringLE(allBytes, counterObj, end) {
	var temp = [];
	var bytes = readBytes(allBytes, counterObj, end);
	for (var idx = bytes.length - 1; idx >= 0; idx--) {
		temp.push(("0" + (bytes[idx] & 0xff).toString(16)).slice(-2));
	}
	return temp.join("").replace(/\u0000+$/g, '');
}

function extractBits(byte, startBit, endBit) {
	if (byte < 0 || byte > 0xffff) {
	  throw new Error("byte must be in range 0..65535");
	}
	if (startBit >= endBit) {
	  throw new Error("invalid bit range");
	}
  
	var width = endBit - startBit;
	var mask = (1 << width) - 1;
	return (byte >>> startBit) & mask;
}

function pickArrayItem(array, index, idName) {
	for (var i = 0; i < array.length; i++) { 
		if (array[i][idName] === index) {
			return array[i];
		}
	}

	return {};
}

function insertArrayItem(array, item, idName) {
	for (var i = 0; i < array.length; i++) { 
		if (array[i][idName] === item[idName]) {
			array[i] = item;
			return;
		}
	}
	array.push(item);
}

function readCommand(allBytes, counterObj, end) {
	var bytes = readBytes(allBytes, counterObj, end);
	var cmd = bytes
		.map(function(b) {
			var hex = b.toString(16);
			return hex.length === 1 ? '0' + hex : hex;
		})
		.join('')
		.toLowerCase();

	var map = cmdMap();
	for (var key in map) {
		var xxs = [];
		var isMatch = false;
		if (key.length !== cmd.length) {
			continue;
		}
		for (var i = 0; i < key.length; i += 2) {
			var hexString = key.slice(i, i + 2);
			var cmdString = cmd.slice(i, i + 2);
			if (hexString === cmdString || hexString === 'xx') {
				if (hexString === 'xx') {
					xxs.push('.' + parseInt(cmdString, 16));
				}
				isMatch = true;
				continue;
			} else {
				isMatch = false;
				break;
			}
		}
		if (isMatch) {
			var propertyId = map[key];
			if (propertyId.indexOf('._item') === -1) {
				return propertyId;
			}
			var j = 0;
			var result = propertyId.replace(/\._item/g, function() {
				return xxs[j++];
			});
			return result;
		}
	}
	return null;
}

function hasPath(obj, path) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length; i++) {
	  	if (!current || !(parts[i] in current)) {
			return false;
	  	}
	  	current = current[parts[i]];
	}
  
	return true;
}

function getPath(obj, path) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length; i++) {
	  	var key = parts[i];
  
	  	if (!current || !(key in current)) {
			return null;
	  	}
  
	  	current = current[key];
	}
  
	return current;
}
  

function setPath(obj, path, value) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length - 1; i++) {
	  	var key = parts[i];
  
	  	if (!(key in current) || typeof current[key] !== 'object') {
			current[key] = {};
	  	}
  
	  	current = current[key];
	}

	current[parts[parts.length - 1]] = value;
	return obj;
}

function convertName(propertyId, prefix) {
	var parts = propertyId.split('.');
	var lastPart = parts[parts.length - 1];
	parts[parts.length - 1] = prefix + '_' + lastPart;
	return parts.join('.');
}

function recoverName(propertyId, prefix) {
	var parts = propertyId.split('.');
	var lastPart = parts[parts.length - 1];
	parts[parts.length - 1] = lastPart.replace(prefix + '_', '');
	return parts.join('.');
}

function getAllLeafPaths(obj, prefix) {
	var paths = [];

	function recurse(current, path) {
	  if (Array.isArray(current)) {
		current.forEach(function (item, index) {
		  var newPath = path ? (path + "." + index) : String(index);
		  recurse(item, newPath);
		});
  
	  } else if (typeof current === 'object' && current !== null) {
		for (var key in current) {
		  if (Object.prototype.hasOwnProperty.call(current, key)) {
			var newPath = path ? (path + "." + key) : key;
			recurse(current[key], newPath);
		  }
		}
  
	  } else {
		paths.push(path);
	  }
	}
  
	recurse(obj, "");
	return paths;
  
}

function isInteger(str) {
	return typeof str === 'string' && /^[0-9]+$/.test(str);
}

function cmdMap() {
	return {
		  "57": "query_motor_stroke_position",
		  "58": "calibrate_motor",
		  "59": "set_target_valve_opening_degree",
		  "60": "temperature_unit",
		  "61": "temperature_source_settings",
		  "62": "environment_temperature_display_enable",
		  "63": "heating_period_settings",
		  "65": "temp_control",
		  "66": "window_opening_detection_settings",
		  "67": "auto_away_settings",
		  "68": "anti_freeze_protection_setting",
		  "69": "mandatory_heating_enable",
		  "70": "motor_controllable_range",
		  "6101": "temperature_source_settings.external_ntc_reception",
		  "6102": "temperature_source_settings.lorawan_reception",
		  "6300": "heating_period_settings.heating_date_settings",
		  "6301": "heating_period_settings.heating_period_reporting_interval",
		  "6302": "heating_period_settings.non_heating_period_reporting_interval",
		  "6303": "heating_period_settings.valve_status_control",
		  "6500": "temp_control.enable",
		  "6501": "temp_control.target_temperature_resolution",
		  "6502": "temp_control.under_temperature_side_deadband",
		  "6503": "temp_control.over_temperature_side_deadband",
		  "6504": "temp_control.target_temperature_adjustment_range_min",
		  "6505": "temp_control.target_temperature_adjustment_range_max",
		  "6506": "temp_control.mode_settings",
		  "630100": "heating_period_settings.heating_period_reporting_interval.seconds_of_time",
		  "630101": "heating_period_settings.heating_period_reporting_interval.minutes_of_time",
		  "630200": "heating_period_settings.non_heating_period_reporting_interval.seconds_of_time",
		  "630201": "heating_period_settings.non_heating_period_reporting_interval.minutes_of_time",
		  "650600": "temp_control.mode_settings.auto_control",
		  "650601": "temp_control.mode_settings.valve_control",
		  "650602": "temp_control.mode_settings.intergrated_control",
		  "ff": "request_check_sequence_number",
		  "fe": "request_check_order",
		  "ef": "command_queries_reply",
		  "ee": "request_query_all_configurations",
		  "ed": "historical_data_report",
		  "cf": "lorawan_configuration_settings",
		  "cfd8": "lorawan_configuration_settings.version",
		  "df": "tsl_version",
		  "de": "product_name",
		  "dd": "product_pn",
		  "db": "product_sn",
		  "da": "version",
		  "d9": "oem_id",
		  "c8": "device_status",
		  "d8": "product_frequency_band",
		  "00": "battery",
		  "01": "temperature",
		  "02": "motor_total_stroke",
		  "03": "motor_position",
		  "04": "valve_opening_degree",
		  "05": "motor_calibration_result_report",
		  "06": "target_temperature",
		  "07": "target_valve_opening_degree",
		  "08": "low_battery_alarm",
		  "09": "temperature_alarm",
		  "0910": "temperature_alarm.lower_range_alarm_deactivation",
		  "0911": "temperature_alarm.lower_range_alarm_trigger",
		  "0912": "temperature_alarm.over_range_alarm_deactivation",
		  "0913": "temperature_alarm.over_range_alarm_trigger",
		  "0a": "anti_freeze_protection_alarm",
		  "0a20": "anti_freeze_protection_alarm.lifted",
		  "0a21": "anti_freeze_protection_alarm.trigger",
		  "0b": "mandatory_heating_alarm",
		  "0b20": "mandatory_heating_alarm.exit",
		  "0b21": "mandatory_heating_alarm.enter",
		  "0c": "auto_away_report",
		  "0c20": "auto_away_report.inactive_by_target_temperature",
		  "0c21": "auto_away_report.active_by_target_temperature",
		  "0c22": "auto_away_report.inactive_by_target_valve_opening",
		  "0c23": "auto_away_report.active_by_target_valve_opening",
		  "0d": "window_opening_alarm",
		  "0d20": "window_opening_alarm.release",
		  "0d21": "window_opening_alarm.trigger",
		  "0e": "periodic_reporting",
		  "0e00": "periodic_reporting.non_heating_season",
		  "0e01": "periodic_reporting.target_temperature_for_heating",
		  "0e02": "periodic_reporting.target_valve_opening_for_heating",
		  "0e03": "periodic_reporting.integrated_control_for_heating",
		  "c9": "random_key",
		  "c4": "auto_p_enable",
		  "6a": "child_lock",
		  "6b": "motor_stroke_limit",
		  "6c": "temperature_calibration_settings",
		  "6d": "temperature_alarm_settings",
		  "6e": "schedule_settings",
		  "6exx": "schedule_settings._item",
		  "6exx00": "schedule_settings._item.enable",
		  "6exx01": "schedule_settings._item.start_time",
		  "6exx02": "schedule_settings._item.cycle_settings",
		  "6exx03": "schedule_settings._item.temperature_control_mode",
		  "6exx04": "schedule_settings._item.target_temperature",
		  "6exx05": "schedule_settings._item.target_valve_status",
		  "6exx06": "schedule_settings._item.pre_heating_enable",
		  "6exx07": "schedule_settings._item.pre_heating_mode",
		  "6exx08": "schedule_settings._item.pre_heating_manual_time",
		  "6exx09": "schedule_settings._item.report_cycle",
		  "6f": "change_report_enable",
		  "c7": "time_zone",
		  "c6": "daylight_saving_time",
		  "c5": "data_storage_settings",
		  "c500": "data_storage_settings.enable",
		  "c501": "data_storage_settings.retransmission_enable",
		  "c502": "data_storage_settings.retransmission_interval",
		  "c503": "data_storage_settings.retrieval_interval",
		  "b6": "reconnect",
		  "b9": "query_device_status",
		  "b8": "synchronize_time",
		  "b7": "set_time",
		  "b5": "collect_data",
		  "bd": "clear_historical_data",
		  "bc": "stop_historical_data_retrieval",
		  "bb": "retrieve_historical_data_by_time_range",
		  "ba": "retrieve_historical_data_by_time",
		  "5a": "set_target_temperature",
		  "5b": "set_temperature",
		  "5c": "set_occupancy_state",
		  "5d": "set_opening_window",
		  "5e": "delete_schedule",
		  "bf": "reset",
		  "be": "reboot"
	};
}
function processTemperature(decoded) {
	var allTemperatureProperties = {
    "temperature": {
        "precision": 2
    },
    "target_temperature": {
        "precision": 1
    },
    "temperature_alarm.lower_range_alarm_deactivation.temperature": {
        "precision": 1
    },
    "temperature_alarm.lower_range_alarm_trigger.temperature": {
        "precision": 1
    },
    "temperature_alarm.over_range_alarm_deactivation.temperature": {
        "precision": 1
    },
    "temperature_alarm.over_range_alarm_trigger.temperature": {
        "precision": 1
    },
    "anti_freeze_protection_alarm.lifted.environment_temperature": {
        "precision": 1
    },
    "anti_freeze_protection_alarm.trigger.environment_temperature": {
        "precision": 1
    },
    "mandatory_heating_alarm.exit.environment_temperature": {
        "precision": 1
    },
    "mandatory_heating_alarm.enter.environment_temperature": {
        "precision": 1
    },
    "auto_away_report.inactive_by_target_temperature.environment_temperature": {
        "precision": 1
    },
    "auto_away_report.inactive_by_target_temperature.target_temperature": {
        "precision": 1
    },
    "auto_away_report.active_by_target_temperature.environment_temperature": {
        "precision": 1
    },
    "auto_away_report.active_by_target_temperature.target_temperature": {
        "precision": 1
    },
    "auto_away_report.inactive_by_target_valve_opening.environment_temperature": {
        "precision": 1
    },
    "auto_away_report.active_by_target_valve_opening.environment_temperature": {
        "precision": 1
    },
    "window_opening_alarm.release.environment_temperature": {
        "precision": 1
    },
    "window_opening_alarm.trigger.environment_temperature": {
        "precision": 1
    },
    "periodic_reporting.target_temperature_for_heating.environment_temperature": {
        "precision": 1
    },
    "periodic_reporting.target_temperature_for_heating.target_temperature": {
        "precision": 1
    },
    "periodic_reporting.target_valve_opening_for_heating.environment_temperature": {
        "precision": 1
    },
    "periodic_reporting.integrated_control_for_heating.environment_temperature": {
        "precision": 1
    },
    "periodic_reporting.integrated_control_for_heating.target_temperature": {
        "precision": 1
    },
    "temp_control.target_temperature_resolution": {
        "precision": null
    },
    "temp_control.under_temperature_side_deadband": {
        "precision": 1
    },
    "temp_control.over_temperature_side_deadband": {
        "precision": 1
    },
    "temp_control.target_temperature_adjustment_range_min": {
        "precision": 1
    },
    "temp_control.target_temperature_adjustment_range_max": {
        "precision": 1
    },
    "temp_control.mode_settings.auto_control.target_temperature": {
        "precision": 1
    },
    "temp_control.mode_settings.intergrated_control.target_temp": {
        "precision": 1
    },
    "window_opening_detection_settings.cooling_rate": {
        "precision": 1
    },
    "auto_away_settings.energy_saving_settings.energy_saving_temperature": {
        "precision": 1
    },
    "anti_freeze_protection_setting.temperature_value": {
        "precision": 1
    },
    "temperature_calibration_settings.calibration_value": {
        "precision": 1
    },
    "temperature_alarm_settings.threshold_min": {
        "precision": 1
    },
    "temperature_alarm_settings.threshold_max": {
        "precision": 1
    },
    "schedule_settings._item.target_temperature": {
        "precision": 1
    },
    "set_target_temperature.value": {
        "precision": 1
    },
    "set_temperature.value": {
        "precision": 1
    }
};
	var leafPaths = getAllLeafPaths(decoded);
	for (var i = 0; i < leafPaths.length; i++) {
		var propertyId = leafPaths[i];
		var propertyParts = propertyId.split('.');
		var newPropertyParts = []
		for (var j = 0; j < propertyParts.length; j++) {
			var part = propertyParts[j];
			if (isInteger(part)) {
				newPropertyParts.push('_item');
			} else {
				newPropertyParts.push(part);
			}
		}
		var newPropertyId = newPropertyParts.join('.');
		newPropertyId = recoverName(newPropertyId, 'fahrenheit');
		newPropertyId = recoverName(newPropertyId, 'celsius');
		propertyId = recoverName(propertyId, 'fahrenheit');
		propertyId = recoverName(propertyId, 'celsius');
		if (allTemperatureProperties[newPropertyId]) {
			var fahrenheitProperty = convertName(propertyId, 'fahrenheit');
			var celsiusProperty = convertName(propertyId, 'celsius');
			if (hasPath(decoded, propertyId)) {
				setPath(decoded, fahrenheitProperty,  Number((getPath(decoded, propertyId) * 1.8 + 32).toFixed(allTemperatureProperties[newPropertyId].precision)));
				setPath(decoded, celsiusProperty,  Number(getPath(decoded, propertyId).toFixed(allTemperatureProperties[newPropertyId].precision)));
			}
		}	
	}	
	return decoded;
}