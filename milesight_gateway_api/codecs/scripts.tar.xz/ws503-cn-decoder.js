/**
 * Payload Decoder
 *
 * Copyright 2025 Milesight IoT
 *
 * @product WS503_CN
 */
var RAW_VALUE = 0x01;

/* eslint no-redeclare: "off" */
/* eslint-disable */
// Chirpstack v4
function decodeUplink(input) {
    var decoded = milesightDeviceDecode(input.bytes);
    return { data: decoded };
}

// Chirpstack v3
function Decode(fPort, bytes) {
    return milesightDeviceDecode(bytes);
}

// The Things Network
function Decoder(bytes, port) {
    return milesightDeviceDecode(bytes);
}
/* eslint-enable */

function milesightDeviceDecode(bytes) {
    var decoded = {};

    for (var i = 0; i < bytes.length; ) {
        var channel_id = bytes[i++];
        var channel_type = bytes[i++];

        // IPSO VERSION
        if (channel_id === 0xff && channel_type === 0x01) {
            decoded.ipso_version = readProtocolVersion(bytes[i]);
            i += 1;
        }
        // HARDWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x09) {
            decoded.hardware_version = readHardwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // FIRMWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x0a) {
            decoded.firmware_version = readFirmwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // TSL VERSION
        else if (channel_id === 0xff && channel_type === 0xff) {
            decoded.tsl_version = readTslVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // SERIAL NUMBER
        else if (channel_id === 0xff && channel_type === 0x16) {
            decoded.sn = readSerialNumber(bytes.slice(i, i + 8));
            i += 8;
        }
        // LORAWAN CLASS TYPE
        else if (channel_id === 0xff && channel_type === 0x0f) {
            decoded.lorawan_class = readLoRaWANClass(bytes[i]);
            i += 1;
        }
        // RESET EVENT
        else if (channel_id === 0xff && channel_type === 0xfe) {
            decoded.reset_event = readResetEvent(1);
            i += 1;
        }
        // DEVICE STATUS
        else if (channel_id === 0xff && channel_type === 0x0b) {
            decoded.device_status = readOnOffStatus(1);
            i += 1;
        }
        // SWITCH STATE
        else if (channel_id === 0x08 && channel_type === 0x29) {
            // payload (0 0 0 0 0 0 0 0)
            //  Switch    3 2 1   3 2 1
            //          ------- -------
            // bit mask  change   state
            var value = bytes[i];
            decoded.switch_1 = readOnOffStatus((value >>> 0) & 0x01);
            decoded.switch_1_change = readYesNoStatus((value >>> 4) & 0x01);
            decoded.switch_2 = readOnOffStatus((value >>> 1) & 0x01);
            decoded.switch_2_change = readYesNoStatus((value >>> 5) & 0x01);
            decoded.switch_3 = readOnOffStatus((value >>> 2) & 0x01);
            decoded.switch_3_change = readYesNoStatus((value >>> 6) & 0x01);
            i += 1;
        }
        // RULE CONFIG
        else if (channel_id === 0xf9 && channel_type === 0x67) {
            var rule_config = readRuleConfig(bytes.slice(i, i + 7));
            i += 7;

            decoded.rule_config = decoded.rule_config || [];
            decoded.rule_config.push(rule_config);
        }
        // DOWNLINK RESPONSE
        else if (channel_id === 0xfe || channel_id === 0xff) {
            var result = handle_downlink_response(channel_type, bytes, i);
            decoded = Object.assign(decoded, result.data);
            i = result.offset;
        } else if (channel_id === 0xf8 || channel_id === 0xf9) {
            var result = handle_downlink_response_ext(channel_type, bytes, i);
            decoded = Object.assign(decoded, result.data);
            i = result.offset;
        } else {
            break;
        }
    }

    return decoded;
}

function handle_downlink_response(channel_type, bytes, offset) {
    var decoded = {};

    switch (channel_type) {
        case 0x03:
            decoded.report_interval = readUInt16LE(bytes.slice(offset, offset + 2));
            offset += 2;
            break;
        case 0x10:
            decoded.reboot = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x22:
            decoded.frame_count = readUInt8(bytes[offset]);
            decoded.delay_time = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            var data = readUInt8(bytes[offset + 3]);
            var switch_bit_offset = { switch_1: 0, switch_2: 1, switch_3: 2 };
            for (var key in switch_bit_offset) {
                if ((data >>> (switch_bit_offset[key] + 4)) & 0x01) {
                    decoded[key] = readOnOffStatus((data >> switch_bit_offset[key]) & 0x01);
                }
            }
            offset += 4;
            break;
        case 0x23:
            decoded.cancel_delay_task = readUInt8(bytes[offset]);
            // ignore the second byte
            offset += 2;
            break;
        case 0x25:
            var data = readUInt16LE(bytes.slice(offset, offset + 2));
            decoded.child_lock_config = {};
            decoded.child_lock_config.enable = readEnableStatus((data >>> 15) & 0x01);
            decoded.child_lock_config.lock_time = data & 0x7fff;
            offset += 2;
            break;
        case 0x28:
            decoded.report_status = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x2c:
            decoded.report_attribute = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x2f:
            decoded.led_mode = readLedMode(bytes[offset]);
            offset += 1;
            break;
        case 0x4a:
            decoded.sync_time = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x5e:
            decoded.reset_button_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        default:
            throw new Error("unknown downlink response");
    }

    return { data: decoded, offset: offset };
}

function handle_downlink_response_ext(channel_type, bytes, offset) {
    var decoded = {};

    switch (channel_type) {
        case 0x64:
            var rule_config_result = readUInt8(bytes[offset + 7]);
            if (rule_config_result === 0) {
                var rule_config = readRuleConfig(bytes.slice(offset, offset + 7));
                decoded.rule_config = decoded.rule_config || [];
                decoded.rule_config.push(rule_config);
            } else {
                decoded.rule_config_result = readRuleConfigResult(rule_config_result);
            }
            offset += 9;
            break;
        case 0x65:
            var query_rule_config_result = readUInt8(bytes[offset + 1]);
            if (query_rule_config_result === 0) {
                var data = readUInt8(bytes[offset]);
                if (data === 0xff) {
                    decoded.query_rule_config_request = readYesNoStatus(1);
                } else {
                    var rule_id_name = "rule_" + data;
                    decoded.query_rule_config_request = decoded.query_rule_config_request || {};
                    decoded.query_rule_config_request[rule_id_name] = readYesNoStatus(1);
                }
            }
            offset += 2;
            break;
        case 0xbd:
            decoded.time_zone = readTimeZone(readInt16LE(bytes.slice(offset, offset + 2)));
            offset += 2;
            break;
        default:
            throw new Error("unknown downlink response");
    }

    return { data: decoded, offset: offset };
}

function readProtocolVersion(bytes) {
    var major = (bytes & 0xf0) >> 4;
    var minor = bytes & 0x0f;
    return "v" + major + "." + minor;
}

function readHardwareVersion(bytes) {
    var major = (bytes[0] & 0xff).toString(16);
    var minor = (bytes[1] & 0xff) >> 4;
    return "v" + major + "." + minor;
}

function readFirmwareVersion(bytes) {
	var major = (bytes[0] & 0xff).toString(16);
	var minor = (bytes[1] & 0xff).toString(16);
	var release = (bytes[2] & 0xff).toString(16);
	var alpha = (bytes[3] & 0xff).toString(16);
	var unit_test = (bytes[4] & 0xff).toString(16);
	var test = (bytes[5] & 0xff).toString(16);

	var version = 'v' + major + '.' + minor;
	if (release !== '0') version += '-r' + release;
	if (alpha !== '0') version += '-a' + alpha;
	if (unit_test !== '0') version += '-u' + unit_test;
	if (test !== '0') version += '-t' + test;
	return version;
}

function readTslVersion(bytes) {
    var major = bytes[0] & 0xff;
    var minor = bytes[1] & 0xff;
    return "v" + major + "." + minor;
}

function readSerialNumber(bytes) {
    var temp = [];
    for (var idx = 0; idx < bytes.length; idx++) {
        temp.push(("0" + (bytes[idx] & 0xff).toString(16)).slice(-2));
    }
    return temp.join("");
}

function readLoRaWANClass(type) {
    var class_map = {
        0: "Class A",
        1: "Class B",
        2: "Class C",
        3: "Class CtoB",
    };
    return getValue(class_map, type);
}

function readResetEvent(status) {
    var status_map = { 0: "normal", 1: "reset" };
    return getValue(status_map, status);
}

function readOnOffStatus(status) {
    var status_map = { 0: "off", 1: "on" };
    return getValue(status_map, status);
}

function readYesNoStatus(status) {
    var status_map = { 0: "no", 1: "yes" };
    return getValue(status_map, status);
}

function readRuleConfig(bytes) {
    var offset = 0;

    var rule_config = {};
    rule_config.rule_id = readUInt8(bytes[offset]);
    var rule_type_value = readUInt8(bytes[offset + 1]);
    rule_config.rule_type = readRuleType(rule_type_value);
    if (rule_type_value !== 0) {
        // condition
        var day_bit_offset = { monday: 0, tuesday: 1, wednesday: 2, thursday: 3, friday: 4, saturday: 5, sunday: 6 };
        rule_config.condition = {};
        var day = readUInt8(bytes[offset + 2]);
        for (var key in day_bit_offset) {
            rule_config.condition[key] = readEnableStatus((day >> day_bit_offset[key]) & 0x01);
        }
        rule_config.condition.hour = readUInt8(bytes[offset + 3]);
        rule_config.condition.minute = readUInt8(bytes[offset + 4]);

        // action
        var switch_bit_offset = { switch_1: 0, switch_2: 2, switch_3: 4 };
        rule_config.action = {};
        var switch_raw_data = readUInt8(bytes[offset + 5]);
        for (var key in switch_bit_offset) {
            rule_config.action[key] = readSwitchStatus((switch_raw_data >> switch_bit_offset[key]) & 0x03);
        }
        rule_config.action.child_lock = readChildLockStatus(bytes[offset + 6]);
    }

    offset += 6;
    return rule_config;
}

function readRuleType(type) {
    var rule_type_map = { 0: "none", 1: "enable", 2: "disable" };
    return getValue(rule_type_map, type);
}

function readSwitchStatus(status) {
    var switch_status_map = { 0: "keep", 1: "on", 2: "off" };
    return getValue(switch_status_map, status);
}

function readRuleConfigResult(result) {
    var rule_config_result_map = {
        0: "success",
        2: "failed, out of range",
        17: "success, conflict with rule_id=1",
        18: "success, conflict with rule_id=2",
        19: "success, conflict with rule_id=3",
        20: "success, conflict with rule_id=4",
        21: "success, conflict with rule_id=5",
        22: "success, conflict with rule_id=6",
        23: "success, conflict with rule_id=7",
        24: "success, conflict with rule_id=8",
        49: "failed, conflict with rule_id=1",
        50: "failed, conflict with rule_id=2",
        51: "failed, conflict with rule_id=3",
        52: "failed, conflict with rule_id=4",
        53: "failed, conflict with rule_id=5",
        54: "failed, conflict with rule_id=6",
        55: "failed, conflict with rule_id=7",
        56: "failed, conflict with rule_id=8",
        81: "failed,rule config empty",
    };
    return getValue(rule_config_result_map, result);
}

function readChildLockStatus(status) {
    var child_lock_status_map = { 0: "keep", 1: "enable", 2: "disable" };
    return getValue(child_lock_status_map, status);
}

function readLedMode(bytes) {
    var led_mode_map = { 0: "off", 1: "on_inverted", 2: "on_synced" };
    return getValue(led_mode_map, bytes);
}

function readEnableStatus(status) {
    var status_map = { 0: "disable", 1: "enable" };
    return getValue(status_map, status);
}

function readTimeZone(time_zone) {
    var timezone_map = { "-720": "UTC-12", "-660": "UTC-11", "-600": "UTC-10", "-570": "UTC-9:30", "-540": "UTC-9", "-480": "UTC-8", "-420": "UTC-7", "-360": "UTC-6", "-300": "UTC-5", "-240": "UTC-4", "-210": "UTC-3:30", "-180": "UTC-3", "-120": "UTC-2", "-60": "UTC-1", 0: "UTC", 60: "UTC+1", 120: "UTC+2", 180: "UTC+3", 210: "UTC+3:30", 240: "UTC+4", 270: "UTC+4:30", 300: "UTC+5", 330: "UTC+5:30", 345: "UTC+5:45", 360: "UTC+6", 390: "UTC+6:30", 420: "UTC+7", 480: "UTC+8", 540: "UTC+9", 570: "UTC+9:30", 600: "UTC+10", 630: "UTC+10:30", 660: "UTC+11", 720: "UTC+12", 765: "UTC+12:45", 780: "UTC+13", 840: "UTC+14" };
    return getValue(timezone_map, time_zone);
}

/* eslint-disable */
function readUInt8(bytes) {
    return bytes & 0xff;
}

function readInt8(bytes) {
    var ref = readUInt8(bytes);
    return ref > 0x7f ? ref - 0x100 : ref;
}

function readUInt16LE(bytes) {
    var value = (bytes[1] << 8) + bytes[0];
    return value & 0xffff;
}

function readInt16LE(bytes) {
    var ref = readUInt16LE(bytes);
    return ref > 0x7fff ? ref - 0x10000 : ref;
}

function readUInt32LE(bytes) {
    var value = (bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + bytes[0];
    return (value & 0xffffffff) >>> 0;
}

function readInt32LE(bytes) {
    var ref = readUInt32LE(bytes);
    return ref > 0x7fffffff ? ref - 0x100000000 : ref;
}

function getValue(map, key) {
    if (RAW_VALUE) return key;

    var value = map[key];
    if (!value) value = "unknown";
    return value;
}

//if (!Object.assign) {
    Object.defineProperty(Object, "assign", {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function (target) {
            "use strict";
            if (target == null) {
                throw new TypeError("Cannot convert first argument to object");
            }

            var to = Object(target);
            for (var i = 1; i < arguments.length; i++) {
                var nextSource = arguments[i];
                if (nextSource == null) {
                    continue;
                }
                nextSource = Object(nextSource);

                var keysArray = Object.keys(Object(nextSource));
                for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                        // concat array
                        if (Array.isArray(to[nextKey]) && Array.isArray(nextSource[nextKey])) {
                            to[nextKey] = to[nextKey].concat(nextSource[nextKey]);
                        } else {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
    });
//}
