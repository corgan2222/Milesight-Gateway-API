/**
 * Payload Decoder
 *
 * Copyright 2025 Milesight IoT
 *
 * @product EM320-TH
 */
var RAW_VALUE = 0x01;

/* eslint no-redeclare: "off" */
/* eslint-disable */
// Chirpstack v4
function decodeUplink(input) {
    var decoded = milesightDeviceDecode(input.bytes);
    return { data: decoded };
}

// Chirpstack v3
function Decode(fPort, bytes) {
    return milesightDeviceDecode(bytes);
}

// The Things Network
function Decoder(bytes, port) {
    return milesightDeviceDecode(bytes);
}
/* eslint-enable */

function milesightDeviceDecode(bytes) {
    var decoded = {};

    for (var i = 0; i < bytes.length;) {
        var channel_id = bytes[i++];
        var channel_type = bytes[i++];

        // IPSO VERSION
        if (channel_id === 0xff && channel_type === 0x01) {
            decoded.ipso_version = readProtocolVersion(bytes[i]);
            i += 1;
        }
        // HARDWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x09) {
            decoded.hardware_version = readHardwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // FIRMWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x0a) {
            decoded.firmware_version = readFirmwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // TSL VERSION
        else if (channel_id === 0xff && channel_type === 0xff) {
            decoded.tsl_version = readTslVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // SERIAL NUMBER
        else if (channel_id === 0xff && channel_type === 0x16) {
            decoded.sn = readSerialNumber(bytes.slice(i, i + 8));
            i += 8;
        }
        // LORAWAN CLASS TYPE
        else if (channel_id === 0xff && channel_type === 0x0f) {
            decoded.lorawan_class = readLoRaWANClass(bytes[i]);
            i += 1;
        }
        // RESET EVENT
        else if (channel_id === 0xff && channel_type === 0xfe) {
            decoded.reset_event = readResetEvent(1);
            i += 1;
        }
        // OEM ID
        else if (channel_id === 0xff && channel_type === 0xe7) {
            decoded.odm_id = readOdmId(bytes.slice(i, i + 2));
            i += 2;
        }
        // SUB VERSION
        else if (channel_id === 0xff && channel_type === 0xe8) {
            decoded.sub_version = readSubVersion(bytes.slice(i, i + 4));
            i += 4;
        }
        // DEVICE STATUS
        else if (channel_id === 0xff && channel_type === 0x0b) {
            decoded.device_status = readDeviceStatus(1);
            i += 1;
        }

        // BATTERY
        else if (channel_id === 0x01 && channel_type === 0x75) {
            decoded.battery = readUInt8(bytes[i]);
            i += 1;
        }
        // TEMPERATURE
        else if (channel_id === 0x03 && channel_type === 0x67) {
            var tempRaw = readUInt16LE(bytes.slice(i, i + 2));
            if (tempRaw === 0x8001) {
                decoded.temperature = "collection_err";
            } else if (tempRaw === 0x8002) {
                decoded.temperature = "lower_range_err";
            } else if (tempRaw === 0x8003) {
                decoded.temperature = "over_range_err";
            } else {
                decoded.temperature = (tempRaw > 0x7fff ? tempRaw - 0x10000 : tempRaw) / 10;
            }
            i += 2;
        }
        // HUMIDITY
        else if (channel_id === 0x04 && channel_type === 0x9A) {
            var humidityRaw = readUInt16LE(bytes.slice(i, i + 2));
            if (humidityRaw === 0xFFFF) {
                decoded.humidity = "collection_err";
            } else {
                decoded.humidity = humidityRaw / 10;
            }
            i += 2;
        }
        // HUMIDITY
        else if (channel_id === 0x04 && channel_type === 0x68) {
            if (bytes[i] === 0xFF) {
                decoded.humidity = "collection_err";
            } else {
                decoded.humidity = readUInt8(bytes[i]) / 2;
            }
            i += 1;
        }
        else if (channel_id === 0x05 && channel_type === 0x6B) {
            // 触发类型
            decoded.trigger_type = readTriggerType(readUInt8(bytes[i]));
            i += 1;
        }
        // STORAGE STATUS (V1.7+, cert version only)
        else if (channel_id === 0x05 && channel_type === 0x9c) {
            decoded.storage_status = readStorageStatus(bytes[i]);
            i += 1;
        }
        else if (channel_id === 0x83 && channel_type === 0x67) {
            decoded.temperature_threshold_alarm =  {};
            decoded.temperature_threshold_alarm.temperature = readInt16LE(bytes.slice(i, i + 2)) / 10;
            decoded.temperature_threshold_alarm.alarm_type = readAlarmType(bytes[i + 2]);
            i += 3;
        }
        else if (channel_id === 0x93 && channel_type === 0x67) {
            decoded.temperature_mutation_alarm =  {};
            decoded.temperature_mutation_alarm.temperature = readInt16LE(bytes.slice(i, i + 2)) / 10;
            decoded.temperature_mutation_alarm.temperature_change = readInt16LE(bytes.slice(i + 2, i + 4)) / 10;
            var alarm_type = readUInt8(bytes[i + 4]);
            if (alarm_type === 0) {
                decoded.temperature_mutation_alarm.alarm_type = 'Temperature mutation';
            }
            i += 5;
        }
        else if (channel_id === 0x84 && channel_type === 0x9A) {
            decoded.humidity_threshold_alarm =  {};
            decoded.humidity_threshold_alarm.relative_humidity = readInt16LE(bytes.slice(i, i + 2)) / 10;
            decoded.humidity_threshold_alarm.alarm_type = readAlarmType(bytes[i + 2]);
            i += 3;
        }
        else if (channel_id === 0x94 && channel_type === 0x9A) {
            decoded.humidity_mutation_alarm =  {};
            decoded.humidity_mutation_alarm.relative_humidity = readInt16LE(bytes.slice(i, i + 2)) / 10;
            decoded.humidity_mutation_alarm.relative_humidity_change = readInt16LE(bytes.slice(i + 2, i + 4)) / 10;
            var alarm_type = readUInt8(bytes[i + 4]);
            if (alarm_type === 0) {
                decoded.humidity_mutation_alarm.alarm_type = 'Humidity mutation';
            }
            i += 5;
        }
        else if (channel_id === 0x84 && channel_type === 0x68) {
            decoded.humidity_threshold_alarm =  {};
            decoded.humidity_threshold_alarm.relative_humidity = readUInt8(bytes[i]) / 2;
            decoded.humidity_threshold_alarm.alarm_type = readAlarmType(bytes[i + 1]);
            i += 2;
        }
        else if (channel_id === 0x94 && channel_type === 0x68) {
            decoded.humidity_mutation_alarm =  {};
            decoded.humidity_mutation_alarm.relative_humidity = readUInt8(bytes[i]) / 2;
            decoded.humidity_mutation_alarm.relative_humidity_change = readUInt8(bytes[i + 1]) / 2;
            var alarm_type = readUInt8(bytes[i + 2]);
            if (alarm_type === 0) {
                decoded.humidity_mutation_alarm.alarm_type = 'Humidity mutation';
            }
            i += 3;
        }
        // Temperature error
        else if (channel_id === 0xb3 && channel_type === 0x67) {
            decoded.temperature_error = readTemperatureError(readUInt8(bytes[i]));
            i += 2;
        }
        else if (channel_id === 0xb4 && channel_type === 0x68) {
            decoded.humidity_error = readHumidityError(readUInt8(bytes[i]));
            i += 2;
        }
        else if (channel_id === 0xb4 && channel_type === 0x9A) {
            decoded.humidity_error = readHumidityError(readUInt8(bytes[i]));
            i += 2;
        }
        // HISTORY
        else if (channel_id === 0x20 && channel_type === 0xce) {
            var data = {};
            data.timestamp = readUInt32LE(bytes.slice(i, i + 4));
            data.temperature = readInt16LE(bytes.slice(i + 4, i + 6)) / 10;
            var humidity = readUInt16LE(bytes.slice(i + 6, i + 8));
            if (humidity === 0xffff) {
                data.humidity = "collection_err";
            } else {
                data.humidity = humidity / 10;
            }
            data.record_type = readRecordType(readUInt8(bytes[i + 8]));
            i += 9;
            decoded.history = decoded.history || [];
            decoded.history.push(data);
        }
        // FULL STORAGE ALARM ENABLE (V1.7+, cert version only)
        else if (channel_id === 0xf9 && channel_type === 0xc9) {
            decoded.full_storage_alarm_enable = readEnableStatus(bytes[i]);
            i += 1;
        }
        else if (channel_id === 0xf9 && channel_type === 0x39) {
            decoded.collection_interval = readUInt16LE(bytes.slice(i, i + 2));
            i += 2;
        }
        else if (channel_id === 0xf9 && channel_type === 0x0b) {
            decoded.alarm_config = {};
            decoded.alarm_config.id = readUInt8(bytes[i]);
            decoded.alarm_config.condition = readMathConditionType(bytes[i + 1]);
            decoded.alarm_config.threshold_min = readInt16LE(bytes.slice(i + 2, i + 4)) / 10;
            decoded.alarm_config.threshold_max = readInt16LE(bytes.slice(i + 4, i + 6)) / 10;
            decoded.alarm_config.enable = readEnableStatus(bytes[i + 6]);
            i += 7;
        }
        else if (channel_id === 0xf9 && channel_type === 0x0c) {
            decoded.mutation_config = {};
            decoded.mutation_config.id = readUInt8(bytes[i]);
            decoded.mutation_config.mutation_max = readInt16LE(bytes.slice(i + 1, i + 3)) / 10;
            decoded.mutation_config.enable = readEnableStatus(bytes[i + 3]);
            i += 4;
        }
        else if (channel_id === 0xf9 && channel_type === 0xd9) {
            decoded.humidity_resolution = readHumidityResolution(bytes[i]);
            i += 1;
        }
        else if (channel_id === 0xf9 && channel_type === 0x69) {
            decoded.button_lock = {};
            var mask = readUInt8(bytes[i]);
            decoded.button_lock.power_off = readEnableStatus((mask >> 0) & 0x01);
            decoded.button_lock.collect_report = readEnableStatus((mask >> 1) & 0x01);
            i += 1;
        }
        else if (channel_id === 0xf9 && channel_type === 0x66) {
            decoded.d2d_enable = readEnableStatus(bytes[i]);
            i += 1;
        }
        else if (channel_id === 0xf9 && channel_type === 0x63) {
            decoded.d2d_sender_config = {};
            decoded.d2d_sender_config.d2d_sender_enable = readEnableStatus(bytes[i]);
            decoded.d2d_sender_config.uplink_lora_enable = readEnableStatus(bytes[i + 1]);
            decoded.d2d_sender_config.sensor_data_enable = readUInt16LE(bytes.slice(i + 2, i + 4));
            i += 4;
        }
        // DOWNLINK RESPONSE
        else if (channel_id === 0xfe || channel_id === 0xff || channel_id === 0xf8) {
            var result = handle_downlink_response(channel_id, channel_type, bytes, i);
            decoded = Object.assign(decoded, result.data);
            i = result.offset;
        } else {
            break;
        }
    }

    return decoded;
}

function handle_downlink_response(channel_id, channel_type, bytes, offset) {
    var decoded = {};
    var has_result_flag = hasResultFlag(channel_id);

    switch (channel_type) {
        case 0x35:
            decoded.d2d_key = readD2DKey(bytes.slice(offset, offset + 8));
            offset += 8;
            break;
        case 0x8e:
            // ID Skip reserved
            decoded.report_interval = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            offset += 3;
            break;
        case 0xf2:
            decoded.alarm_count = readUInt16LE(bytes.slice(offset, offset + 2));
            offset += 2;
            break;
        case 0xf5:
            decoded.threshold_release = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        case 0xea:
            var ctrl = readUInt8(bytes[offset]);
            decoded.calibration_config = {};
            decoded.calibration_config.id = ctrl & 0x7f;
            decoded.calibration_config.enable = readEnableStatus((ctrl >> 7) & 0x01);
            decoded.calibration_config.calibration_value = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            offset += 3;
            break;
        case 0x10:
            decoded.reboot = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x27:
            decoded.clear_history = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x28:
            decoded.report_status = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x68:
            decoded.history_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        case 0x69:
            decoded.retransmit_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        case 0x6a:
            var interval_type = readUInt8(bytes[offset]);
            if (interval_type === 0) {
                decoded.retransmit_interval = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            } else if (interval_type === 1) {
                decoded.resend_interval = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            }
            offset += 3;
            break;
        // FULL STORAGE ALARM ENABLE (V1.7+, cert version only)
        case 0xc9:
            decoded.full_storage_alarm_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            // For F8 channel, read result code
            if (has_result_flag) {
                var result_code = readUInt8(bytes[offset]);
                offset += 1;
                if (result_code !== 0) {
                    var request = decoded;
                    decoded = {};
                    decoded.device_response_result = {};
                    decoded.device_response_result.channel_type = channel_type;
                    decoded.device_response_result.result = readResultStatus(result_code);
                    decoded.device_response_result.request = request;
                }
            }
            break;
        default:
            throw new Error("unknown downlink response");
    }

    return { data: decoded, offset: offset };
}

function readProtocolVersion(bytes) {
    var major = (bytes & 0xf0) >> 4;
    var minor = bytes & 0x0f;
    return "v" + major + "." + minor;
}

function readHardwareVersion(bytes) {
    var major = (bytes[0] & 0xff).toString(16);
    var minor = (bytes[1] & 0xff) >> 4;
    return "v" + major + "." + minor;
}

function readFirmwareVersion(bytes) {
	var major = (bytes[0] & 0xff).toString(16);
	var minor = (bytes[1] & 0xff).toString(16);
	var release = (bytes[2] & 0xff).toString(16);
	var alpha = (bytes[3] & 0xff).toString(16);
	var unit_test = (bytes[4] & 0xff).toString(16);
	var test = (bytes[5] & 0xff).toString(16);

	var version = 'v' + major + '.' + minor;
	if (release !== '0') version += '-r' + release;
	if (alpha !== '0') version += '-a' + alpha;
	if (unit_test !== '0') version += '-u' + unit_test;
	if (test !== '0') version += '-t' + test;
	return version;
}

function readOdmId(bytes) {
    var id = "";
    for (var i = 0; i < bytes.length; i++) {
        id += ("0" + (bytes[i] & 0xff).toString(16)).slice(-2);
    }
    return id;
}

/**
 * read sub version
 * @param {number[]} bytes values: release(1B) + alpha(1B) + test(2B)
 * @example 01020011 -> "r1-a2-t11"
 */
function readSubVersion(bytes) {
    var release = (bytes[0] & 0xff).toString(16);
    var alpha = (bytes[1] & 0xff).toString(16);
    var test = (((bytes[2] & 0xff) << 8) + (bytes[3] & 0xff)).toString(16);
    return "r" + release + "-a" + alpha + "-t" + test;
}

function readTslVersion(bytes) {
    var major = bytes[0] & 0xff;
    var minor = bytes[1] & 0xff;
    return "v" + major + "." + minor;
}

function readSerialNumber(bytes) {
    var temp = [];
    for (var idx = 0; idx < bytes.length; idx++) {
        temp.push(("0" + (bytes[idx] & 0xff).toString(16)).slice(-2));
    }
    return temp.join("");
}

function readLoRaWANClass(type) {
    var class_map = {
        0: "Class A",
        1: "Class B",
        2: "Class C",
        3: "Class CtoB",
    };
    return getValue(class_map, type);
}

function readHumidityResolution(resolution) {
    var resolution_map = { 0: "0.5%", 1: "0.1%" };
    return getValue(resolution_map, resolution);
}

function readTriggerType(type) {
    var type_map = { 1: "external_trigger" };
    return getValue(type_map, type);
}

function readRecordType(type) {
    var type_map = { 
        1: "periodic_report",
        2: "manual_operation_report",
        3: "temperature_below",
        4: "temperature_above",
        5: "temperature_within",
        6: "temperature_below_or_above",
        7: "temperature_mutation_alarm",
        8: "temperature_below_clear",
        9: "temperature_above_clear",
        10: "temperature_within_clear",
        11: "temperature_below_or_above_clear",
        12: "temperature_over_range_upper",
        13: "temperature_over_range_lower",
        14: "temperature_collection_err",
        15: "humidity_below",
        16: "humidity_above",
        17: "humidity_within",
        18: "humidity_below_or_above",
        19: "humidity_mutation_alarm",
        20: "humidity_below_clear",
        21: "humidity_above_clear",
        22: "humidity_within_clear",
        23: "humidity_below_or_above_clear",
        24: "humidity_collection_err",
    };
    return getValue(type_map, type);
}

function readD2DKey(bytes) {
    var key = "";
    for (var i = 0; i < bytes.length; i++) {
        key += ("0" + (bytes[i] & 0xff).toString(16)).slice(-2);
    }
    return key;
}

function readTemperatureError(type) {
    var type_map = {
        1: "collection_err",
        2: "lower_range_err",
        3: "over_range_err"
    };
    return getValue(type_map, type);
}

function readHumidityError(type) {
    var type_map = {
        1: "collection_err"
    };
    return getValue(type_map, type);
}

function readAlarmType(type) {
    var type_map = { 
        1: "Below alarm",
        2: "Above alarm",
        3: "Between alarm",
        4: "Outside alarm",

        6: "Below alarm clear",
        7: "Above alarm clear",
        8: "Between alarm clear",
        9: "Outside alarm clear"
    };
    return getValue(type_map, type);
}

function readResetEvent(status) {
    var status_map = { 0: "normal", 1: "reset" };
    return getValue(status_map, status);
}

function readDeviceStatus(status) {
    var status_map = { 0: "off", 1: "on" };
    return getValue(status_map, status);
}

/**
 * read storage status (V1.7+, cert version only)
 * @param {number} status values: (1: sufficient, 2: less_than_10_percent, 3: full, 4: overwritten)
 */
function readStorageStatus(status) {
    var status_map = {
        1: "sufficient",
        2: "less_than_10_percent",
        3: "full",
        4: "overwritten"
    };
    return getValue(status_map, status);
}

function hasResultFlag(channel_id) {
    return channel_id === 0xf8;
}

function readResultStatus(status) {
    var status_map = {
        0: "success",
        1: "forbidden",
        2: "invalid parameter"
    };
    return getValue(status_map, status);
}

function readYesNoStatus(status) {
    var status_map = { 0: "no", 1: "yes" };
    return getValue(status_map, status);
}

function readEnableStatus(status) {
    var status_map = { 0: "disable", 1: "enable" };
    return getValue(status_map, status);
}

function readMathConditionType(type) {
    var type_map = { 0: "disable", 1: "below", 2: "above", 3: "between", 4: "outside" };
    return getValue(type_map, type);
}

/* eslint-disable */
function readUInt8(bytes) {
    return bytes & 0xff;
}

function readInt8(bytes) {
    var ref = readUInt8(bytes);
    return ref > 0x7f ? ref - 0x100 : ref;
}

function readUInt16LE(bytes) {
    var value = (bytes[1] << 8) + bytes[0];
    return value & 0xffff;
}

function readInt16LE(bytes) {
    var ref = readUInt16LE(bytes);
    return ref > 0x7fff ? ref - 0x10000 : ref;
}

function readUInt32LE(bytes) {
    var value = (bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + bytes[0];
    return (value & 0xffffffff) >>> 0;
}

function readInt32LE(bytes) {
    var ref = readUInt32LE(bytes);
    return ref > 0x7fffffff ? ref - 0x100000000 : ref;
}

function getValue(map, key) {
    if (RAW_VALUE) return key;

    var value = map[key];
    if (!value) value = "unknown";
    return value;
}

//if (!Object.assign) {
    Object.defineProperty(Object, "assign", {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function (target) {
            "use strict";
            if (target == null) {
                throw new TypeError("Cannot convert first argument to object");
            }

            var to = Object(target);
            for (var i = 1; i < arguments.length; i++) {
                var nextSource = arguments[i];
                if (nextSource == null) {
                    continue;
                }
                nextSource = Object(nextSource);

                var keysArray = Object.keys(Object(nextSource));
                for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                        // concat array
                        if (Array.isArray(to[nextKey]) && Array.isArray(nextSource[nextKey])) {
                            to[nextKey] = to[nextKey].concat(nextSource[nextKey]);
                        } else {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
    });
//}
