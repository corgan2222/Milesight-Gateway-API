/**
 * Payload Decoder
 *
 * Copyright 2025 Milesight IoT
 *
 * @product WT201 v2
 */
var RAW_VALUE = 0x01;

/* eslint no-redeclare: "off" */
/* eslint-disable */
// Chirpstack v4
function decodeUplink(input) {
    var decoded = milesightDeviceDecode(input.bytes);
    return { data: decoded };
}

// Chirpstack v3
function Decode(fPort, bytes) {
    return milesightDeviceDecode(bytes);
}

// The Things Network
function Decoder(bytes, port) {
    return milesightDeviceDecode(bytes);
}
/* eslint-enable */

function milesightDeviceDecode(bytes) {
    var decoded = {};

    for (var i = 0; i < bytes.length; ) {
        var channel_id = bytes[i++];
        var channel_type = bytes[i++];

        // IPSO VERSION
        if (channel_id === 0xff && channel_type === 0x01) {
            decoded.ipso_version = readProtocolVersion(bytes[i]);
            i += 1;
        }
        // HARDWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x09) {
            decoded.hardware_version = readHardwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // FIRMWARE VERSION
        else if (channel_id === 0xff && channel_type === 0x0a) {
            decoded.firmware_version = readFirmwareVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // TSL VERSION
        else if (channel_id === 0xff && channel_type === 0xff) {
            decoded.tsl_version = readTslVersion(bytes.slice(i, i + 2));
            i += 2;
        }
        // SERIAL NUMBER
        else if (channel_id === 0xff && channel_type === 0x16) {
            decoded.sn = readSerialNumber(bytes.slice(i, i + 8));
            i += 8;
        }
        // LORAWAN CLASS TYPE
        else if (channel_id === 0xff && channel_type === 0x0f) {
            var type = bytes[i];
            var lorawan_class_map = {
                0: "Class A",
                1: "Class B",
                2: "Class C",
                3: "Class CtoB"
            }
            decoded.lorawan_class = {};
            decoded.lorawan_class.type = getMapValue(lorawan_class_map, type, type + 1);
            if (RAW_VALUE) {
                decoded.lorawan_class.value = getMapKey(lorawan_class_map, type, type + 1);
            } 
            i += 1;
        }
        // RESET EVENT
        else if (channel_id === 0xff && channel_type === 0xfe) {
            decoded.reset_event = readResetEvent(1);
            i += 1;
        }
        // DEVICE STATUS
        else if (channel_id === 0xff && channel_type === 0x0b) {
            decoded.device_status = readDeviceStatus(1);
            i += 1;
        }
        // TEMPERATURE
        else if (channel_id === 0x03 && channel_type === 0x67) {
            decoded.ambient_temperature = readInt16LE(bytes.slice(i, i + 2)) / 10;
            i += 2;
        }
        // TARGET TEMPERATURE
        else if (channel_id === 0x04 && channel_type === 0x67) {
            decoded.target_temperature = readInt16LE(bytes.slice(i, i + 2)) / 10;
            i += 2;
        }
        // TARGET TEMPERATURE 2
        else if (channel_id === 0x0b && channel_type === 0x67) {
            decoded.target_temperature_2 = readInt16LE(bytes.slice(i, i + 2)) / 10;
            i += 2;
        }
        // TEMPERATURE CONTROL
        else if (channel_id === 0x05 && channel_type === 0xe7) {
            var value = bytes[i];
            var temperature_control_mode_map = {
                0: "heat",
                1: "em heat",
                2: "cool",
                3: "auto"
            };
            decoded.current_temperature_control_mode = {};
            // value = temperature_control_mode(0..1) + temperature_control_status(4..7)
            decoded.current_temperature_control_mode.mode = temperature_control_mode_map[(value >>> 0) & 0x03];
            decoded.current_temperature_control_mode.status = readTemperatureControlStatus((value >>> 4) & 0x0f);
            if (RAW_VALUE) {
                decoded.current_temperature_control_mode.mode_value = ((value >>> 0) & 0x03) + 1;
                decoded.current_temperature_control_mode.status_value = ((value >>> 4) & 0x0f) + 1;
            }

            i += 1;
        }
        // FAN CONTROL
        else if (channel_id === 0x06 && channel_type === 0xe8) {
            var fan_data = bytes[i];
            var fan_mode_map = [ 
                { value: 2, name: "auto" },
                { value: 3, name: "always on" },
                { value: 4, name: "circulate" },
                { value: 1, name: "disable" }
            ]; 
            var fan_status_map = [
                { value: 1, name: "standby" },
                { value: 5, name: "high speed" },
                { value: 3, name: "low speed" },
                { value: 2, name: "on" }
            ];
            decoded.fan_mode_setting = {};
            // value = fan_mode(0..1) + fan_status(2..3)
            decoded.fan_mode_setting.mode = fan_mode_map[(fan_data >>> 0) & 0x03]['name'];
            decoded.fan_mode_setting.status = fan_status_map[(fan_data >>> 2) & 0x07]['name'];
            if (RAW_VALUE) {
                decoded.fan_mode_setting.mode_value = fan_mode_map[(fan_data >>> 0) & 0x03]['value'];
                decoded.fan_mode_setting.status_value = fan_status_map[(fan_data >>> 2) & 0x07]['value'];
            }
            i += 1;
        }

        // fireware version 1.5
        // CURRENT TEMPERATURE HUMIDITY SOURCE
        else if (channel_id === 0x07 && channel_type === 0xe9) {
            var sourceResult = readTemperatureHumiditySource(bytes[i]);
            decoded.curr_temperature_humidity_source = sourceResult.source;
            if (RAW_VALUE) {
                decoded.curr_temperature_humidity_source_value = sourceResult.value;
            }
            i += 1;
        }
        else if (channel_id === 0x87 && channel_type === 0xe9) {
            var sourceResult = readTemperatureHumiditySource(bytes[i]);
            var alarm_map = {
                1: "source switch alarm"
            }
            decoded.source_alarm = {};
            decoded.source_alarm.source = sourceResult.source;
            decoded.source_alarm.alarm = alarm_map[bytes[i + 1]];
            if (RAW_VALUE) {
                decoded.source_alarm.source_value = sourceResult.value;
                decoded.source_alarm.alarm_value = bytes[i + 1];
            }
            i += 2;
        }

        // PLAN EVENT
        else if (channel_id === 0x07 && channel_type === 0xbc) {
            var plan_type_data = bytes[i];
            // value = plan_type(0..3)
            decoded.plan_type = readExecutePlanType((plan_type_data >>> 0) & 0x0f);
            i += 1;
        }
        // SYSTEM STATUS
        else if (channel_id === 0x08 && channel_type === 0x8e) {
            decoded.system_status = readOnOffStatus(bytes[i]);
            i += 1;
        }
        // HUMIDITY
        else if (channel_id === 0x09 && channel_type === 0x68) {
            decoded.humidity = readUInt8(bytes[i]) / 2;
            i += 1;
        }
        // RELAY STATUS
        else if (channel_id === 0x0a && channel_type === 0x6e) {
            decoded.enabled_relay = readWiresRelay(bytes[i]);
            i += 1;
        }
        // TEMPERATURE MODE SUPPORT
        else if (channel_id === 0xff && channel_type === 0xcb) {
            decoded.temperature_control_support_mode = readTemperatureControlSupportMode(bytes[i]);
            decoded.temperature_control_support_status = readTemperatureControlSupportStatus(bytes[i + 1], bytes[i + 2]);
            i += 3;
        }
        // TEMPERATURE ALARM
        else if (channel_id === 0x83 && channel_type === 0x67) {
            decoded.temperature = readInt16LE(bytes.slice(i, i + 2)) / 10;
            decoded.temperature_alarm = readTemperatureAlarm(bytes[i + 2]);
            i += 3;
        }
        // TEMPERATURE EXCEPTION
        else if (channel_id === 0xb3 && channel_type === 0x67) {
            decoded.temperature_sensor_status = readSensorStatus(bytes[i]);
            i += 1;
        }
        // HUMIDITY EXCEPTION
        else if (channel_id === 0xb9 && channel_type === 0x68) {
            decoded.humidity_sensor_status = readSensorStatus(bytes[i]);
            i += 1;
        }
        // TEMPERATURE OUT OF RANGE ALARM
        else if (channel_id === 0xf9 && channel_type === 0x40) {
            var target_temperature_range_alarm = {};
            target_temperature_range_alarm.temperature_control_mode = readTemperatureControlMode(bytes[i]);
            target_temperature_range_alarm.target_temperature = readInt16LE(bytes.slice(i + 1, i + 3)) / 10;
            target_temperature_range_alarm.min = readInt16LE(bytes.slice(i + 3, i + 5)) / 10;
            target_temperature_range_alarm.max = readInt16LE(bytes.slice(i + 5, i + 7)) / 10;
            i += 7;

            decoded.target_temperature_range_alarm = decoded.target_temperature_range_alarm || [];
            decoded.target_temperature_range_alarm.push(target_temperature_range_alarm);
        }
        // HISTORICAL DATA
        else if (channel_id === 0x20 && channel_type === 0xce) {
            var timestamp = readUInt32LE(bytes.slice(i, i + 4));
            var value1 = readUInt16LE(bytes.slice(i + 4, i + 6));

            var data = {};
            data.timestamp = timestamp;
            // value1 = system_status(0) + fan_mode(1..2) + fan_status(3..4) + temperature_control_mode(5..6) + temperature_control_status(7..10)
            data.system_status = readOnOffStatus(value1 & 0x01);
            data.fan_mode = readFanMode((value1 >>> 1) & 0x03);
            data.fan_status = readFanStatus((value1 >>> 3) & 0x03);
            data.temperature_control_mode = readTemperatureControlMode((value1 >>> 5) & 0x03);
            data.temperature_control_status = readTemperatureControlStatus((value1 >>> 7) & 0x0f);

            data.target_temperature = readInt16LE(bytes.slice(i + 6, i + 8)) / 10;
            var temperature_target_value = readUInt16LE(bytes.slice(i + 8, i + 10));
            if (temperature_target_value !== 0xffff) {
                data.target_temperature_2 = readInt16LE(bytes.slice(i + 8, i + 10)) / 10;
            }
            data.temperature = readInt16LE(bytes.slice(i + 10, i + 12)) / 10;
            data.humidity = readUInt8(bytes[i + 12]) / 2;
            i += 13;

            decoded.history = decoded.history || [];
            decoded.history.push(data);
        }
        // DOWNLINK RESPONSE
        else if (channel_id === 0xfe || channel_id === 0xff) {
            var result = handle_downlink_response(channel_type, bytes, i);
            decoded = Object.assign(decoded, result.data);
            i = result.offset;
        } else if (channel_id === 0xf8 || channel_id === 0xf9) {
            var resultExt = handle_downlink_response_ext(channel_id, channel_type, bytes, i);
            decoded = Object.assign(decoded, resultExt.data);
            i = resultExt.offset;
        } else {
            break;
        }
    }
    processTemperature(decoded);
    return decoded;
}

function handle_downlink_response(channel_type, bytes, offset) {
    var decoded = {};

    switch (channel_type) {
        case 0x02:
            decoded.collection_interval = readUInt16LE(bytes.slice(offset, offset + 2));
            offset += 2;
            break;
        case 0x03:
            decoded.outside_temperature = readInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x06: // temperature_alarm_config
            var ctl = readUInt8(bytes[offset]);
            var condition = ctl & 0x07;
            var alarm_type = (ctl >>> 3) & 0x07;

            var condition_map = { 0: "disable", 1: "below", 2: "above", 3: "between", 4: "outside" };
            var alarm_type_map = { 0: "temperature threshold", 1: "continuous low temperature", 2: "continuous high temperature" };
            var data = { condition: getValue(condition_map, condition), alarm_type: getValue(alarm_type_map, alarm_type) };

            if (condition === 1 || condition === 3 || condition === 4) {
                data.threshold_min = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            }
            if (condition === 2 || condition === 3 || condition === 4) {
                data.threshold_max = readInt16LE(bytes.slice(offset + 3, offset + 5)) / 10;
            }
            data.lock_time = readInt16LE(bytes.slice(offset + 5, offset + 7));
            data.continue_time = readInt16LE(bytes.slice(offset + 7, offset + 9));
            offset += 9;

            decoded.temperature_alarm_config = data;
            break;
        case 0x10:
            decoded.reboot = readYesNoStatus(1);
            offset += 1;
            break;
        case 0x25:
            var masked = readUInt8(bytes[offset]);
            var status = readUInt8(bytes[offset + 1]);
            var button_mask_bit_offset = { power_button: 0, up_button: 1, down_button: 2, fan_button: 3, mode_button: 4, reset_button: 5 };

            decoded.child_lock_config = decoded.child_lock_config || {};
            for (var button in button_mask_bit_offset) {
                if ((masked >> button_mask_bit_offset[button]) & 0x01) {
                    decoded.child_lock_config[button] = readEnableStatus((status >> button_mask_bit_offset[button]) & 0x01);
                }
            }
            offset += 2;
            break;
        case 0x28:
            var report_status_map = { 0: "plan", 1: "periodic", 2: "target_temperature_range" };
            decoded.report_status = getValue(report_status_map, readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x68:
            decoded.history_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        case 0x69:
            decoded.retransmit_enable = readEnableStatus(bytes[offset]);
            offset += 1;
            break;
        case 0x6a:
            var interval_type = readUInt8(bytes[offset]);
            switch (interval_type) {
                case 0:
                    decoded.retransmit_interval = readUInt16LE(bytes.slice(offset + 1, offset + 3));
                    break;
                case 1:
                    decoded.resend_interval = readUInt16LE(bytes.slice(offset + 1, offset + 3));
                    break;
            }
            offset += 3;
            break;
        case 0x82:
            var value = readUInt8(bytes[offset]);
            var mask = value >>> 4;
            var enabled = value & 0x0f;

            var group_mask_bit_offset = { group1_enable: 0, group2_enable: 1, group3_enable: 2, group4_enable: 3 };
            decoded.multicast_group_config = {};
            for (var group in group_mask_bit_offset) {
                if ((mask >> group_mask_bit_offset[group]) & 0x01) {
                    decoded.multicast_group_config[group] = readEnableStatus((enabled >> group_mask_bit_offset[group]) & 0x01);
                }
            }
            offset += 1;
            break;
        case 0x83:
            var d2d_slave_config = readD2DSlaveConfig(bytes.slice(offset, offset + 5));
            offset += 5;
            decoded.d2d_slave_config = decoded.d2d_slave_config || [];
            decoded.d2d_slave_config.push(d2d_slave_config);
            break;
        case 0x96:
            var d2d_master_config = readD2DMasterConfig(bytes.slice(offset, offset + 8));
            offset += 8;
            decoded.d2d_master_config = decoded.d2d_master_config || [];
            decoded.d2d_master_config.push(d2d_master_config);
            break;
        case 0x4a:
            decoded.synchronize_time = readUInt8(bytes[offset]);
            offset += 1;
            break;
        case 0x8e:
            // ignore the first byte
            decoded.reporting_interval_settings = {};
            decoded.reporting_interval_settings.time = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            offset += 3;
            break;
        case 0xab:
            decoded.temperature_calibration_settings = {};
            decoded.temperature_calibration_settings.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.temperature_calibration_settings.calibration_value = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            offset += 3;
            break;
        case 0xb0:
            decoded.freeze_protection_config = decoded.freeze_protection_config || {};
            decoded.freeze_protection_config.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.freeze_protection_config.temperature = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            offset += 3;
            break;
        case 0xb5:
            var reversing_valve = readUInt8(bytes[offset]);
            var rawValue_reversing_valve_map = { 0: "energize on heat", 1: "energize on cool" };
            decoded.reversing_valve = {};
            if(RAW_VALUE) {
                decoded.reversing_valve.value = getMapKey(rawValue_reversing_valve_map, reversing_valve, reversing_valve + 1);
                decoded.reversing_valve.mode = getMapValue(rawValue_reversing_valve_map, reversing_valve);
            } else {
                decoded.reversing_valve.mode = getMapValue(rawValue_reversing_valve_map, reversing_valve);
            }
            offset += 1;
            break;
        case 0xb6:
            var mode = readUInt8(bytes[offset]);
            var fan_mode_map = [ 
                { value: 2, name: "auto" },
                { value: 3, name: "always on" },
                { value: 4, name: "circulate" },
            ];
            decoded.fan_mode_setting = {};
            decoded.fan_mode_setting.mode = fan_mode_map[mode]['name'];
            if(RAW_VALUE) {
                decoded.fan_mode_setting.mode_value = fan_mode_map[mode]['value'];
            }
            offset += 1;
            break;
        case 0xb7:
            decoded.temperature_control = {};
            decoded.temperature_control.mode = readTemperatureControlMode(readUInt8(bytes[offset]));
            var t = readUInt8(bytes[offset + 1]);
            decoded.temperature_control.target = t & 0x7f;
            decoded.temperature_control.unit = readTemperatureUnit((t >>> 7) & 0x01);
            offset += 2;
            break;
        case 0xb8:
            decoded.temperature_tolerance = {};
            decoded.temperature_tolerance.target_temperature_tolerance = readUInt8(bytes[offset]) / 10;
            decoded.temperature_tolerance.auto_temperature_tolerance = readUInt8(bytes[offset + 1]) / 10;
            offset += 2;
            break;
        case 0xb9:
            var level_switch_settings = readLevelSwitchSettings(bytes.slice(offset, offset + 3));

            decoded.level_switch_settings = decoded.level_switch_settings || [];
            decoded.level_switch_settings.push(level_switch_settings);
            offset += 3;
            break;
        case 0xba:
            var enable_value = bytes[offset];
            decoded.dst_config = {};
            decoded.dst_config.enable = readEnableStatus(enable_value);
            if (enable_value) {
                decoded.dst_config.offset = readUInt8(bytes[offset + 1]);
                decoded.dst_config.start_month = readUInt8(bytes[offset + 2]);
                var start_day = readUInt8(bytes[offset + 3]);
                decoded.dst_config.start_week_num = (start_day >>> 4) & 0x0f;
                decoded.dst_config.start_week_day = start_day & 0x0f;
                decoded.dst_config.start_time = readUInt16LE(bytes.slice(offset + 4, offset + 6));
                decoded.dst_config.end_month = readUInt8(bytes[offset + 6]);
                var end_day = readUInt8(bytes[offset + 7]);
                decoded.dst_config.end_week_num = (end_day >>> 4) & 0x0f;
                decoded.dst_config.end_week_day = end_day & 0x0f;
                decoded.dst_config.end_time = readUInt16LE(bytes.slice(offset + 8, offset + 10));
            }
            offset += 10;
            break;
        case 0xbd:
            decoded.time_zone = readTimeZone(readInt16LE(bytes.slice(offset, offset + 2)));
            offset += 2;
            break;
        case 0xc1:
            var action_type_map = { 0: "power", 1: "plan" };
            decoded.card_config = {};
            decoded.card_config.enable = readEnableStatus(bytes[offset]);
            var action_type_value = readUInt8(bytes[offset + 1]);
            decoded.card_config.action_type = getValue(action_type_map, action_type_value);
            if (action_type_value === 1) {
                var action = readUInt8(bytes[offset + 2]);
                decoded.card_config.in_plan_type = readPlanType((action >>> 4) & 0x0f);
                decoded.card_config.out_plan_type = readPlanType(action & 0x0f);
            }
            decoded.card_config.invert = readYesNoStatus(bytes[offset + 3]);
            offset += 4;
            break;
        case 0xc2:
            decoded.plan_type = readPlanType(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0xc4:
            decoded.temperature_source_config = {};
            decoded.temperature_source_config.source = readTemperatureSource(readUInt8(bytes[offset]));
            decoded.temperature_source_config.timeout = readUInt8(bytes[offset + 1]);
            offset += 2;
            break;
        case 0xc5:
            decoded.system_status = readOnOffStatus(bytes[offset]);
            offset += 1;
            break;
        case 0xc7:
            var d2d_enable_data = readUInt8(bytes[offset]);
            offset += 1;
            var d2d_enable_mask = d2d_enable_data >>> 4;
            var d2d_enable_status = d2d_enable_data & 0x0f;
            if ((d2d_enable_mask >> 0) & 0x01) {
                decoded.d2d_master_enable = readEnableStatus(d2d_enable_status & 0x01);
            }
            if ((d2d_enable_mask >> 1) & 0x01) {
                decoded.d2d_slave_enable = readEnableStatus((d2d_enable_status >> 1) & 0x01);
            }
            break;
        case 0xc8:
            var plan = readPlan(bytes.slice(offset, offset + 5));
            offset += 5;

            decoded.plan_cfg = decoded.plan_cfg || [];
            decoded.plan_cfg.push(plan);
            break;
        case 0xc9:
            var schedule = readPlanSchedule(bytes.slice(offset, offset + 6));
            offset += 6;

            decoded.plan_schedule = decoded.plan_schedule || [];
            decoded.plan_schedule.push(schedule);
            break;
        case 0xca:
            decoded.wires = readWires(bytes[offset], bytes[offset + 1], bytes[offset + 2]);
            offset += 3;
            break;
        case 0xeb:
            var temperature_unit_map = { 0: "celsius", 1: "fahrenheit" };
            decoded.temperature_unit = {};
            decoded.temperature_unit.unit = temperature_unit_map[bytes[offset]];
            if(RAW_VALUE) {
                decoded.temperature_unit.value = bytes[offset] + 1;
            }
            offset += 1;
            break;
        case 0xf6:
            decoded.control_permission = readControlPermission(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0xf7:
            var wire_relay_bit_offset = { y1: 0, y2_gl: 1, w1: 2, w2_aux: 3, e: 4, g: 5, ob: 6 };
            var wire_relay_mask = readUInt16LE(bytes.slice(offset, offset + 2));
            var wire_relay_status = readUInt16LE(bytes.slice(offset + 2, offset + 4));
            offset += 4;

            decoded.wires_relay_config = {};
            for (var key in wire_relay_bit_offset) {
                if ((wire_relay_mask >>> wire_relay_bit_offset[key]) & 0x01) {
                    decoded.wires_relay_config[key] = readOnOffStatus((wire_relay_status >>> wire_relay_bit_offset[key]) & 0x01);
                }
            }
            break;
        case 0xf8:
            decoded.offline_control_mode = readOfflineControlMode(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0xf9:
            decoded.humidity_calibration_settings = {};
            decoded.humidity_calibration_settings.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.humidity_calibration_settings.calibration_value = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            offset += 3;
            break;
        case 0xfa:
            decoded.temperature_control_mode = readTemperatureControlMode(readUInt8(bytes[offset]));
            decoded.target_temperature = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            offset += 3;
            break;
        case 0xfb:
            var mode = readUInt8(bytes[offset]);
            var mode_map = { 1: "heat", 2: "em heat", 3: "cool", 4: "auto" };
            decoded.current_temperature_control_mode = {};

            if (RAW_VALUE) {
                decoded.current_temperature_control_mode.mode_value = mode + 1;
                decoded.current_temperature_control_mode.mode = mode_map[mode + 1];
            } else {
                decoded.current_temperature_control_mode.mode = mode_map[mode + 1];
            }
            offset += 1;
            break;
        default:
            throw new Error("unknown downlink response");
    }

    return { data: decoded, offset: offset };
}

function handle_downlink_response_ext(code, channel_type, bytes, offset) {
    var decoded = {};

    switch (channel_type) {
        case 0x05:
            decoded.fan_delay = {};
            decoded.fan_delay.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.fan_delay.time = readUInt8(bytes[offset + 1]);
            offset += 2;
            break;
        case 0x06:
            decoded.fan_execute_time = readUInt8(bytes[offset]);
            offset += 1;
            break;
        case 0x07:
            decoded.fan_dehumidify = {};
            var enable_value = readUInt8(bytes[offset]);
            decoded.fan_dehumidify.enable = readEnableStatus(enable_value);
            if (enable_value) {
                decoded.fan_dehumidify.execute_time = readUInt8(bytes[offset + 1]);
            }
            offset += 2;
            break;
        case 0x08:
            var screen_display_mode_map = { 0: "on", 1: "without plan show", 2: "disable all" };
            decoded.screen_display_mode = getValue(screen_display_mode_map, readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x09:
            decoded.humidity_range = {};
            decoded.humidity_range.min = readUInt8(bytes[offset]);
            decoded.humidity_range.max = readUInt8(bytes[offset + 1]);
            offset += 2;
            break;
        case 0x0a:
            decoded.temperature_dehumidify = {};
            decoded.temperature_dehumidify.enable = readEnableStatus(readUInt8(bytes[offset]));
            var temperature_tolerance_value = readUInt8(bytes[offset + 1]);
            if (temperature_tolerance_value !== 0xff) {
                decoded.temperature_dehumidify.temperature_tolerance = temperature_tolerance_value / 10;
            }
            offset += 2;
            break;
        case 0x1b:
            var masked = readUInt8(bytes[offset]);
            var enabled = readUInt8(bytes[offset + 1]);
            decoded.temperature_up_down_enable = {};
            var bit_offset = { forward_enable: 0, backward_enable: 1 };
            for (var key in bit_offset) {
                if ((masked >>> bit_offset[key]) & 0x01) {
                    decoded.temperature_up_down_enable[key] = readEnableStatus((enabled >>> bit_offset[key]) & 0x01);
                }
            }
            offset += 2;
            break;

        // fireware version 1.4
        case 0x29:
            var offline_timeout = readUInt8(bytes[offset]);
            decoded.offline_timeout = {};
            if(RAW_VALUE) {
                var rawValue_offline_timeout_map = { 255: 1, 5: 2, 10: 3, 20: 4, 30: 5, 40: 6, 50: 7, 60: 8 };
                decoded.offline_timeout.value = rawValue_offline_timeout_map[offline_timeout];
                decoded.offline_timeout.time = offline_timeout === 255 ? "disable" : offline_timeout;
            } else {
                decoded.offline_timeout.time = offline_timeout === 255 ? "disable" : offline_timeout;
            }
            offset += 1;
            break;
        case 0x2a:
            decoded.heartbeat = readUInt8(bytes[offset]);
            offset += 1;
            break;
        
        case 0x3a:
            decoded.wires_relay_change_report_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x3b:
            var value = readUInt8(bytes[offset]);
            decoded.aux_control_config = {};
            var aux_control_bit_offset = { y2_enable: 0, w2_enable: 1 };
            for (var aux_wire_key in aux_control_bit_offset) {
                if ((value >>> (aux_control_bit_offset[aux_wire_key] + 4)) & 0x01) {
                    decoded.aux_control_config[aux_wire_key] = readEnableStatus((value >>> aux_control_bit_offset[aux_wire_key]) & 0x01);
                }
            }
            offset += 1;
            break;
        case 0x3e:
            var d2d_master_id = {};
            d2d_master_id.id = readUInt8(bytes[offset]) + 1;
            d2d_master_id.dev_eui = toHexString(bytes.slice(offset + 1, offset + 9));
            offset += 9;
            decoded.d2d_master_ids = decoded.d2d_master_ids || [];
            decoded.d2d_master_ids.push(d2d_master_id);
            break;
        case 0x41:
            decoded.target_temperature_resolution = readTemperatureResolution(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x42:
            decoded.target_temperature_range_config = {};
            decoded.target_temperature_range_config.temperature_control_mode = readTemperatureControlMode(readUInt8(bytes[offset]));
            decoded.target_temperature_range_config.min = readInt16LE(bytes.slice(offset + 1, offset + 3)) / 10;
            decoded.target_temperature_range_config.max = readInt16LE(bytes.slice(offset + 3, offset + 5)) / 10;
            offset += 5;
            break;
        case 0x43:
            decoded.temperature_level_up_down_delta = {};
            // skip the first byte
            decoded.temperature_level_up_down_delta.delta_1 = readUInt8(bytes[offset + 1]) / 10;
            decoded.temperature_level_up_down_delta.delta_2 = readUInt8(bytes[offset + 2]) / 10;
            offset += 3;
            break;
        case 0x44:
            decoded.fan_delay_config = {};
            decoded.fan_delay_config.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.fan_delay_config.delay_time = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            offset += 3;
            break;
        case 0x45:
            decoded.system_status = readOnOffStatus(readUInt8(bytes[offset]));
            decoded.temperature_control_mode = readTemperatureControlMode(readUInt8(bytes[offset + 1]));
            decoded.target_temperature = readInt16LE(bytes.slice(offset + 2, offset + 4)) / 10;
            offset += 4;
            break;
        case 0x46:
            decoded.compressor_aux_combine_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x47:
            decoded.system_protect_config = {};
            decoded.system_protect_config.enable = readEnableStatus(readUInt8(bytes[offset]));
            decoded.system_protect_config.duration = readUInt8(bytes[offset + 1]);
            offset += 2;
            break;
        case 0x58:
            decoded.target_temperature_dual = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x59:
            var dual_temperature_plan_config = readDualTemperaturePlanConfig(bytes.slice(offset, offset + 9));
            decoded.dual_temperature_plan_config = decoded.dual_temperature_plan_config || [];
            decoded.dual_temperature_plan_config.push(dual_temperature_plan_config);
            offset += 9;
            break;
        case 0x5a:
            var double_point_target_tolerance = readDoublePointTargetTolerance(bytes.slice(offset, offset + 2));

            decoded.double_point_target_tolerance = decoded.double_point_target_tolerance || [];
            decoded.double_point_target_tolerance.push(double_point_target_tolerance);
            offset += 2;
            break;
        case 0x5c:
            var unlock_button_bit_offset = { power_button: 0, temperature_up_button: 1, temperature_down_button: 2, fan_mode_button: 3, temperature_control_mode_button: 4 };
            var unlock_button_data = readUInt8(bytes[offset]);
            decoded.unlock_config = {};
            for (var btn in unlock_button_bit_offset) {
                decoded.unlock_config[btn] = readEnableStatus((unlock_button_data >>> unlock_button_bit_offset[btn]) & 0x01);
            }
            decoded.unlock_config.time = readUInt16LE(bytes.slice(offset + 1, offset + 3));
            offset += 3;
            break;
        case 0x5e:
            var single_temperature_plan_config = readSingleTemperaturePlanConfig(bytes.slice(offset, offset + 7));
            decoded.single_temperature_plan_config = decoded.single_temperature_plan_config || [];
            decoded.single_temperature_plan_config.push(single_temperature_plan_config);
            offset += 7;
            break;
        case 0x5d:
            var mode = readUInt8(bytes[offset]);
            var buttons = [];
            var buttons_array = [ "heat", "em heat", "cool", "auto" ];
            for (var i = 0; i < buttons_array.length; i++) {
                if ((mode >>> i) & 0x01) {
                    buttons.push(buttons_array[i]);
                }
            }
            var modes = buttons.join("/");
            decoded.temperature_control_enable_setting = {};
            if(RAW_VALUE) {
                var temperature_control_enable_setting_map = { 
                    1: "heat/em heat/cool/auto", 
                    2: "heat/cool/auto", 
                    3: "heat", 
                    4: "cool", 
                    5: "heat/cool" 
                };
                var values = getValues(temperature_control_enable_setting_map, modes);
                decoded.temperature_control_enable_setting.value = values;
                decoded.temperature_control_enable_setting.mode = getMapValue(temperature_control_enable_setting_map, values);
            } else {
                decoded.temperature_control_enable_setting.mode = modes ? modes : "disable";
            }
            offset += 1;
            break;
        case 0x62:
            decoded.fan_control_during_heating = readFanControlDuringHeating(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x8b:
            decoded.plan_schedule_enable_config = readPlanScheduleEnableConfig(bytes.slice(offset, offset + 2));
            offset += 2;
            break;

        // fireware version 1.5
        case 0x20: 
            decoded.fan_delay_config_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x21: 
            decoded.fan_delay_config_delay_time = readUInt16LE(bytes.slice(offset, offset + 2));
            offset += 2;
            break;
        case 0x22: 
            var temporary_unlock_settings = readUInt8(bytes[offset]);
            var buttons = [];
            var buttons_array = [ "System On/Off", "Temperature +", "Temperature -", "Fan Mode", "Temperature Control Mode" ];
            for (var i = 0; i < buttons_array.length; i++) {
                if ((temporary_unlock_settings >>> i) & 0x01) {
                    buttons.push(buttons_array[i]);
                }
            }
            var settings = buttons.join("&");
            decoded.temporary_unlock_settings = {};
            if(RAW_VALUE) {
                var rawValue_temporary_unlock_settings_map = { 
                    1: "disable",
                    2: "System On/Off&Temperature +",
                    3: "System On/Off&Temperature -",
                    4: "System On/Off&Fan Mode",
                    5: "System On/Off&Temperature Control Mode",
                    6: "Temperature +&Temperature -",
                    7: "Temperature +&Fan Mode",
                    8: "Temperature +&Temperature Control Mode",
                    9: "Temperature -&Fan Mode",
                    10: "Temperature -&Temperature Control Mode",
                    11: "Fan Mode&Temperature Control Mode",
                    12: "System On/Off&Temperature +&Temperature -",
                    13: "System On/Off&Temperature +&Fan Mode",
                    14: "System On/Off&Temperature +&Temperature Control Mode",
                    15: "System On/Off&Temperature -&Fan Mode",
                    16: "System On/Off&Temperature -&Temperature Control Mode",
                    17: "System On/Off&Fan Mode&Temperature Control Mode",
                    18: "Temperature +&Temperature -&Fan Mode",
                    19: "Temperature +&Temperature -&Temperature Control Mode",
                    20: "Temperature +&Fan Mode&Temperature Control Mode",
                    21: "Temperature -&Fan Mode&Temperature Control Mode",
                    22: "System On/Off&Temperature +&Temperature -&Fan Mode",
                    23: "System On/Off&Temperature +&Temperature -&Temperature Control Mode",
                    24: "System On/Off&Temperature +&Fan Mode&Temperature Control Mode",
                    25: "System On/Off&Temperature -&Fan Mode&Temperature Control Mode",
                    26: "Temperature +&Temperature -&Fan Mode&Temperature Control Mode",
                    27: "System On/Off&Temperature +&Temperature -&Fan Mode&Temperature Control Mode"
                };
                decoded.temporary_unlock_settings.value = settings ? getValues(rawValue_temporary_unlock_settings_map, settings) : 1;
                decoded.temporary_unlock_settings.settings = settings ? settings : "disable";
            } else {
                decoded.temporary_unlock_settings.settings = settings ? settings : "disable";
            }
            offset += 1;
            break;
        case 0x23:
            decoded.temperature_control_delta1 = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x24:
            decoded.temperature_control_delta2 = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x27:
            var occupancy_mode = readUInt8(bytes[offset]);
            var rawValue_occupancy_mode_map = { 1: "off", 2: "occupied", 3: "unoccupied" };
            decoded.occupancy_mode = {};
            if(RAW_VALUE) {
                decoded.occupancy_mode.value = occupancy_mode;
                decoded.occupancy_mode.mode = rawValue_occupancy_mode_map[occupancy_mode];
            } else {
                decoded.occupancy_mode.mode = rawValue_occupancy_mode_map[occupancy_mode];
            }
            offset += 1;
            break;
        case 0x28:
            var occupied_delay = readUInt8(bytes[offset]);
            decoded.occupied_delay = {};
            if(RAW_VALUE) {
                var rawValue_occupied_delay_map = { 255: 1, 5: 2, 10: 3, 20: 4, 30: 5, 40: 6, 50: 7, 60: 8 };
                decoded.occupied_delay.value = rawValue_occupied_delay_map[occupied_delay];
                decoded.occupied_delay.time = occupied_delay === 255 ? "disable" : occupied_delay;
            } else {
                decoded.occupied_delay.time = occupied_delay === 255 ? "disable" : occupied_delay;
            }
            offset += 1;
            break;
        case 0x2b:
            decoded.unilateral_tolerance = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x2c:
            var time_format = readUInt8(bytes[offset]);
            var time_format_map = { 1: "12 Hour (AM-PM)", 2: "24 Hour" };
            decoded.time_format = {};
            if (RAW_VALUE) {
                decoded.time_format.value = time_format;
                decoded.time_format.mode = time_format_map[time_format];
            } else {
                decoded.time_format.mode = time_format_map[time_format];
            }
            offset += 1;
            break;
        case 0x2d:
            var wire_mode = readUInt8(bytes[offset]);
            var wire_mode_map = { 1: "standard", 2: "custom" };
            decoded.wire_mode = {};
            if(RAW_VALUE) {
                decoded.wire_mode.value = wire_mode;
                decoded.wire_mode.mode = wire_mode_map[wire_mode];
            } else {
                decoded.wire_mode.mode = wire_mode_map[wire_mode];
            }
            offset += 1;
            break;
        case 0x2e:
            var temperature_humidity_source = readUInt8(bytes[offset]);
            var temperature_humidity_source_map = [
                { value: 1, name: "embedded" },
                { value: 3, name: "lora" },
                { value: 4, name: "d2d" },
            ];
            decoded.temperature_humidity_source = {};
            if(RAW_VALUE) {
                decoded.temperature_humidity_source.value = temperature_humidity_source_map[temperature_humidity_source - 1]['value'];
                decoded.temperature_humidity_source.mode = temperature_humidity_source_map[temperature_humidity_source - 1]['name'];
            } else {
                decoded.temperature_humidity_source.mode = temperature_humidity_source_map[temperature_humidity_source - 1]['name'];
            }
            offset += 1;
            break;
        case 0x2f:
            var timezone = readUInt8(bytes[offset]);
            var timezone_map = { 1: "UTC-12", 2: "UTC-11", 3: "UTC-10", 4: "UTC-9:30", 5: "UTC-9", 6: "UTC-8", 7: "UTC-7", 8: "UTC-6", 9: "UTC-5", 10: "UTC-4", 11: "UTC-3:30", 12: "UTC-3", 13: "UTC-2", 14: "UTC-1", 15: "UTC", 16: "UTC+1", 17: "UTC+2", 18: "UTC+3", 19: "UTC+3:30", 20: "UTC+4", 21: "UTC+4:30", 22: "UTC+5", 23: "UTC+5:30", 24: "UTC+5:45", 25: "UTC+6", 26: "UTC+6:30", 27: "UTC+7", 28: "UTC+8", 29: "UTC+9", 30: "UTC+9:30", 31: "UTC+10", 32: "UTC+10:30", 33: "UTC+11", 34: "UTC+12", 35: "UTC+12:45", 36: "UTC+13", 37: "UTC+14" };
            decoded.timezone_index = {};
            if(RAW_VALUE) {
                decoded.timezone_index.value = timezone;
                decoded.timezone_index.timezone = timezone_map[timezone];
            } else {
                decoded.timezone_index.timezone = timezone_map[timezone];
            }
            offset += 1;
            break;
        case 0x30: 
            decoded.timezone_offset = readInt16LE(bytes.slice(offset, offset + 2));
            offset += 2;
            break;
        case 0x31:
            decoded.children_locks_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x32:
            decoded.target_deadband = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x33:
            decoded.sharing_mode_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x64:
            decoded.occupied_cooling_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x65:
            decoded.occupied_heating_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x66:
            decoded.unoccupied_cooling_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x67:
            decoded.unoccupied_heating_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x68:
            decoded.cooling_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x69:
            decoded.heating_setpoint = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x6a:
            decoded.occupied_cooling_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x6b:
            decoded.occupied_heating_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x6c:
            decoded.unoccupied_cooling_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x6d:
            decoded.unoccupied_heating_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x6e:
            decoded.cooling_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x6f:
            decoded.heating_setpoint_tolerance = readUInt8(bytes[offset]) / 10;
            offset += 1;
            break;
        case 0x72:
            decoded.center_cool_temp = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x73:
            decoded.center_heat_temp = readUInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x74:
            decoded.cooling_adjust_tolerance = readInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x75:
            decoded.heating_adjust_tolerance = readInt16LE(bytes.slice(offset, offset + 2)) / 10;
            offset += 2;
            break;
        case 0x80:
            decoded.custom_wiring_mode = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x81:
            decoded.heating_stage1 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x82:
            decoded.heating_stage2 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x83:
            decoded.heating_stage3 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x84:
            decoded.heating_stage4 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x85:
            decoded.heating_stage5 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x86:
            decoded.emergency_heating = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x87:
            decoded.cooling_stage1 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x88:
            decoded.cooling_stage2 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x89:
            decoded.cooling_stage3 = readTemperatureControlStage(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x90:
            decoded.screen_display_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x91:
            decoded.screen_time_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x92:
            decoded.screen_target_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x93:
            decoded.screen_temp_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x94:
            decoded.screen_humi_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x95:
            decoded.screen_plan_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        case 0x96:
            decoded.screen_target_others_enable = readEnableStatus(readUInt8(bytes[offset]));
            offset += 1;
            break;
        default:
            throw new Error("unknown downlink response");
    }

    if (hasResultFlag(code)) {
        var result_value = readUInt8(bytes[offset]);
        offset += 1;

        if (result_value !== 0) {
            var request = decoded;
            decoded = {};
            decoded.device_response_result = {};
            decoded.device_response_result.channel_type = channel_type;
            decoded.device_response_result.result = readResultStatus(result_value);
            decoded.device_response_result.request = request;
        }
    }

    return { data: decoded, offset: offset };
}

function hasResultFlag(code) {
    return code === 0xf8;
}

function readResultStatus(status) {
    var status_map = { 0: "success", 1: "forbidden", 2: "invalid parameter" };
    return getValue(status_map, status);
}

function readProtocolVersion(bytes) {
    var major = (bytes & 0xf0) >> 4;
    var minor = bytes & 0x0f;
    return "v" + major + "." + minor;
}

function readHardwareVersion(bytes) {
    var major = (bytes[0] & 0xff).toString(16);
    var minor = (bytes[1] & 0xff) >> 4;
    return "v" + major + "." + minor;
}

function readFirmwareVersion(bytes) {
	var major = (bytes[0] & 0xff).toString(16);
	var minor = (bytes[1] & 0xff).toString(16);
	var release = (bytes[2] & 0xff).toString(16);
	var alpha = (bytes[3] & 0xff).toString(16);
	var unit_test = (bytes[4] & 0xff).toString(16);
	var test = (bytes[5] & 0xff).toString(16);

	var version = 'v' + major + '.' + minor;
	if (release !== '0') version += '-r' + release;
	if (alpha !== '0') version += '-a' + alpha;
	if (unit_test !== '0') version += '-u' + unit_test;
	if (test !== '0') version += '-t' + test;
	return version;
}

function readTslVersion(bytes) {
    var major = bytes[0] & 0xff;
    var minor = bytes[1] & 0xff;
    return "v" + major + "." + minor;
}

function readSerialNumber(bytes) {
    var temp = [];
    for (var idx = 0; idx < bytes.length; idx++) {
        temp.push(("0" + (bytes[idx] & 0xff).toString(16)).slice(-2));
    }
    return temp.join("");
}

function readLoRaWANClass(type) {
    var class_map = {
        0: "Class A",
        1: "Class B",
        2: "Class C",
        3: "Class CtoB",
    };
    return getValue(class_map, type);
}

function readResetEvent(status) {
    var status_map = { 0: "normal", 1: "reset" };
    return getValue(status_map, status);
}

function readDeviceStatus(status) {
    var status_map = { 0: "off", 1: "on" };
    return getValue(status_map, status);
}

function readEnableStatus(status) {
    var status_map = { 0: "disable", 1: "enable" };
    return getValue(status_map, status);
}

function readYesNoStatus(type) {
    var yes_no_status_map = { 0: "no", 1: "yes" };
    return getValue(yes_no_status_map, type);
}

function readOnOffStatus(type) {
    var on_off_status_map = { 0: "off", 1: "on" };
    return getValue(on_off_status_map, type);
}

function readTemperatureUnit(type) {
    var temperature_unit_map = { 0: "celsius", 1: "fahrenheit" };
    return getValue(temperature_unit_map, type);
}

function readTemperatureResolution(type) {
    var temperature_resolution_map = { 0: 0.5, 1: 1 };
    return getValue(temperature_resolution_map, type);
}

function readTemperatureAlarm(type) {
    var temperature_alarm_map = {
        1: "emergency heating timeout alarm",
        2: "auxiliary heating timeout alarm",
        3: "persistent low temperature alarm",
        4: "persistent low temperature alarm release",
        5: "persistent high temperature alarm",
        6: "persistent high temperature alarm release",
        7: "freeze protection alarm",
        8: "freeze protection alarm release",
        9: "threshold alarm",
        10: "threshold alarm release",
    };
    return getValue(temperature_alarm_map, type);
}

function readSensorStatus(type) {
    var sensor_status_map = {
        1: "read failed",
        2: "out of range",
    };
    return getValue(sensor_status_map, type);
}

function readTemperatureHumiditySource(type) {
    var value_map = {
        1: "embedded",
        2: "loRa",
        3: "d2d",
    };
    var source_map = {
        "embedded": 1,
        "loRa": 3,
        "d2d": 4,
    };
    var source = getMapValue(value_map, type);
    var value = getMapKey(value_map, type, source_map[value_map[type]]);
    if (RAW_VALUE) {
        return {
            source: source,
            value: value
        };
    } else {
        return {
            source: source
        };
    }
}

function readTemperatureControlStage(value) {
    var stage = {};
    var wire_map = {
        1: "disable",
        2: "Y1",
        3: "Y2",
        4: "W1",
        5: "W2(AUX)",
        6: "Y1+Y2",
        7: "Y1+Y2+W1",
        8: "Y1+Y2+W1+W2(AUX)",
        9: "Y1+W1",
        10: "Y1+W1+W2(AUX)",
        11: "W1+W2(AUX)",
        12: "E"
    };

    var wires = [];
    var wires_array = [ "Y1", "Y2", "W1", "W2(AUX)", "E" ];
    for (var i = 0; i < wires_array.length; i++) {
        if ((value >>> i) & 0x01) {
            wires.push(wires_array[i]);
        }
    }
    var settings = wires.length > 0 ? wires.join("+") : "disable";
    var values = getValues(wire_map, settings);
    if(RAW_VALUE) {
        stage.value = values;
        stage.wire = values ? values : "unknown";
    } else {
        stage.wire = settings;
    }

    return stage;
}

function readExecutePlanType(type) {
    var fix_type = type - 1;
    if (fix_type === -1) {
        fix_type = 255;
    }
    var plan_event_map = {
        0: "wake",
        1: "away",
        2: "home",
        3: "sleep",
        4: "occupied",
        5: "vacant",
        6: "eco",
        255: "not executed",
    };
    return getValue(plan_event_map, fix_type);
}

function readPlanType(type) {
    var plan_event_type_map = {
        0: "wake",
        1: "away",
        2: "home",
        3: "sleep",
        4: "occupied",
        5: "vacant",
        6: "eco",
    };
    return getValue(plan_event_type_map, type);
}

function readFanMode(type) {
    var fan_mode_map = {
        0: "auto",
        1: "on",
        2: "circulate",
        3: "disable",
    };
    return getValue(fan_mode_map, type);
}

function readFanStatus(type) {
    var fan_status_map = {
        0: "standby",
        1: "high speed",
        2: "low speed",
        3: "on"
    };
    return getValue(fan_status_map, type);
}

function readControlPermission(type) {
    var control_permission_map = { 0: "thermostat", 1: "remote control" };
    return getValue(control_permission_map, type);
}

function readOfflineControlMode(type) {
    var offline_control_mode_map = { 0: "keep", 1: "thermostat", 2: "off" };
    return getValue(offline_control_mode_map, type);
}

function readPlanId(type) {
    var plan_id_map = {
        0: "wake",
        1: "away",
        2: "home",
        3: "sleep"
    };
    return getValue(plan_id_map, type);
}

function readTempMode(type) {
    var temperature_mode_map = {
        0: "heat",
        1: "em heat",
        2: "cool",
        3: "auto"
    };
    return getValue(temperature_mode_map, type);
}

function readOldFanMode(type) {
    var fan_mode_map = {
        0: "auto",
        1: "on",
        2: "circulate"
    };
    return getValue(fan_mode_map, type);
}

function readTemperatureControlMode(type) {
    var temperature_control_mode_map = {
        0: "heat",
        1: "em heat",
        2: "cool",
        3: "auto",
        4: "auto heat",
        5: "auto cool",
    };
    return getValue(temperature_control_mode_map, type);
}

function readTemperatureControlStatus(type) {
    var temperature_control_status_map = {
        0: "standby",
        1: "stage-1 heat",
        2: "stage-2 heat",
        3: "stage-3 heat",
        4: "stage-4 heat",
        5: "em heat",
        6: "stage-1 cool",
        7: "stage-2 cool",
        8: "stage-5 heat", //hardware version v2.0
        9: "stage-3 cool", //firmware version v1.5
    };
    return getMapValue(temperature_control_status_map, type);
}

function readWires(wire1, wire2, wire3) {
    var wire = {};
    wire.y1 = readOnOffStatus((wire1 >>> 0) & 0x03);
    wire.gh = readOnOffStatus((wire1 >>> 2) & 0x03);
    wire.ob = readOnOffStatus((wire1 >>> 4) & 0x03);
    wire.w1 = readOnOffStatus((wire1 >>> 6) & 0x03);

    wire.e = readOnOffStatus((wire2 >>> 0) & 0x03);
    wire.di = readOnOffStatus((wire2 >>> 2) & 0x03);
    wire.pek = readOnOffStatus((wire2 >>> 4) & 0x03);
    wire.w2 = readOnOffStatus((wire2 >>> 6) & 0x01);
    wire.aux = readOnOffStatus(((wire2 >>> 6) & 0x03) === 2 ? 1 : 0);

    wire.y2 = readOnOffStatus((wire3 >>> 0) & 0x01);
    wire.gl = readOnOffStatus(((wire3 >>> 0) & 0x03) === 2 ? 1 : 0);
    return wire;
}

function readWiresRelay(status) {
    var relay = [];
    var relay_array = [ 'Y1', 'Y2', 'W1', 'W2', 'EH', 'G', 'OB' ];
    for (var i = 0; i < relay_array.length; i++) {
        if ((status >>> i) & 0x01) {
            relay.push(relay_array[i]);
        }
    }
    return relay.length > 0 ? relay.join("&") : "off";
}

function readReversingValve(type) {
    var reversing_valve_map = {
        1: "on cool",
        2: "on heat"
    };
    return getValue(reversing_valve_map, type);
}

function readActionType(type) {
    var action_type_map = {
        0: "power",
        1: "plan",
    };
    return getValue(action_type_map, type);
}

function readTemperatureControlType(type) {
    var temperature_control_type_map = { 0: "heat", 1: "cool" };
    return getValue(temperature_control_type_map, type);
}

function readLevelSwitchSettings(bytes) {
    var level_switch_settings = {};
    level_switch_settings.type = readTemperatureControlType(readUInt8(bytes[0]));
    level_switch_settings.time = readUInt8(bytes[1]);
    level_switch_settings.change_value = readUInt8(bytes[2]) / 10;
    return level_switch_settings;
}

function readTemperatureControlSupportMode(value) {
    var enable = {};
    enable.heat = readEnableStatus((value >>> 0) & 0x01);
    enable.em_heat = readEnableStatus((value >>> 1) & 0x01);
    enable.cool = readEnableStatus((value >>> 2) & 0x01);
    enable.auto = readEnableStatus((value >>> 3) & 0x01);
    return enable;
}

function readTemperatureControlSupportStatus(heat_mode_value, cool_mode_value) {
    var enable = {};
    enable.stage_1_heat = readEnableStatus((heat_mode_value >>> 0) & 0x01);
    enable.stage_2_heat = readEnableStatus((heat_mode_value >>> 1) & 0x01);
    enable.stage_3_heat = readEnableStatus((heat_mode_value >>> 2) & 0x01);
    enable.stage_4_heat = readEnableStatus((heat_mode_value >>> 3) & 0x01);
    enable.stage_5_heat = readEnableStatus((heat_mode_value >>> 4) & 0x01);
    enable.stage_1_cool = readEnableStatus((cool_mode_value >>> 0) & 0x01);
    enable.stage_2_cool = readEnableStatus((cool_mode_value >>> 1) & 0x01);
    enable.stage_3_cool = readEnableStatus((cool_mode_value >>> 2) & 0x01);
    return enable;
}

function readWeekRecycleSettings(value) {
    var week_day_bits_offset = { monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6, sunday: 7 };
    var week_enable = {};
    for (var day in week_day_bits_offset) {
        week_enable[day] = readEnableStatus((value >>> week_day_bits_offset[day]) & 0x01);
    }
    return week_enable;
}

function readTimeZone(time_zone) {
    var timezone_map = { "-720": "UTC-12", "-660": "UTC-11", "-600": "UTC-10", "-570": "UTC-9:30", "-540": "UTC-9", "-480": "UTC-8", "-420": "UTC-7", "-360": "UTC-6", "-300": "UTC-5", "-240": "UTC-4", "-210": "UTC-3:30", "-180": "UTC-3", "-120": "UTC-2", "-60": "UTC-1", 0: "UTC", 60: "UTC+1", 120: "UTC+2", 180: "UTC+3", 210: "UTC+3:30", 240: "UTC+4", 270: "UTC+4:30", 300: "UTC+5", 330: "UTC+5:30", 345: "UTC+5:45", 360: "UTC+6", 390: "UTC+6:30", 420: "UTC+7", 480: "UTC+8", 540: "UTC+9", 570: "UTC+9:30", 600: "UTC+10", 630: "UTC+10:30", 660: "UTC+11", 720: "UTC+12", 765: "UTC+12:45", 780: "UTC+13", 840: "UTC+14" };
    return getValue(timezone_map, time_zone);
}

function readSingleTemperaturePlanConfig(bytes) {
    var offset = 0;

    var config = {};
    config.plan_type = readPlanType(readUInt8(bytes[offset]));
    config.temperature_control_mode = readTemperatureControlMode(readUInt8(bytes[offset + 1]));
    config.fan_mode = readFanMode(readUInt8(bytes[offset + 2]));
    config.target_temperature = readInt16LE(bytes.slice(offset + 3, offset + 5)) / 10;
    config.target_temperature_tolerance = readUInt8(bytes[offset + 5]) / 10;
    config.temperature_control_tolerance = readUInt8(bytes[offset + 6]) / 10;
    return config;
}

function readDoublePointTargetTolerance(bytes) {
    var double_point_target_tolerance = {};
    var mode_map = { 0: "heat", 1: "cool" };
    double_point_target_tolerance.mode = getValue(mode_map, readUInt8(bytes[0]));
    double_point_target_tolerance.tolerance = readUInt8(bytes[1]) / 10;
    return double_point_target_tolerance;
}

function readDualTemperaturePlanConfig(bytes) {
    var offset = 0;

    var config = {};
    config.type = readPlanType(readUInt8(bytes[offset]));
    config.temperature_control_mode = readTemperatureControlMode(readUInt8(bytes[offset + 1]));
    config.fan_mode = readFanMode(readUInt8(bytes[offset + 2]));
    var heat_target_temperature_value = readUInt16LE(bytes.slice(offset + 3, offset + 5));
    if (heat_target_temperature_value !== 0xffff) {
        config.heat_target_temperature = readUInt16LE(bytes.slice(offset + 3, offset + 5)) / 10;
    }
    var heat_temperature_tolerance_value = readUInt8(bytes[offset + 5]);
    if (heat_temperature_tolerance_value !== 0xff) {
        config.heat_temperature_tolerance = heat_temperature_tolerance_value / 10;
    }
    var cool_target_temperature_value = readUInt16LE(bytes.slice(offset + 6, offset + 8));
    if (cool_target_temperature_value !== 0xffff) {
        config.cool_target_temperature = readUInt16LE(bytes.slice(offset + 6, offset + 8)) / 10;
    }
    var cool_temperature_tolerance_value = readUInt8(bytes[offset + 8]);
    if (cool_temperature_tolerance_value !== 0xff) {
        config.cool_temperature_tolerance = cool_temperature_tolerance_value / 10;
    }
    return config;
}

function readPlan(bytes) {
    var offset = 0;
    var plan = {};
    plan.plan_id = readPlanId(bytes[offset]);
    plan.temp_mode = readTempMode(bytes[offset + 1]);
    plan.fan_mode = readOldFanMode(bytes[offset + 2]);
    plan.target = readUInt8(bytes[offset + 3]);
    plan.error = readUInt8(bytes[offset + 4]) / 10;
    return plan;
}

function readPlanSchedule(bytes) {
    var offset = 0;
    var schedule = {};
    schedule.plan_type = readPlanType(bytes[offset]);
    schedule.id = bytes[offset + 1] + 1;
    schedule.enable = readEnableStatus(bytes[offset + 2]);
    schedule.week_recycle = readWeekRecycleSettings(bytes[offset + 3]);
    schedule.time = readUInt16LE(bytes.slice(offset + 4, offset + 6));
    return schedule;
}

function readPlanScheduleEnableConfig(bytes) {
    var offset = 0;
    var mask = readUInt8(bytes[offset]);
    var value = readUInt8(bytes[offset + 1]);

    var plan_schedule_enable_config = {};
    var plan_bit_offset = { wake: 0, away: 1, home: 2, sleep: 3, occupied: 4, vacant: 5, eco: 6 };
    for (var key in plan_bit_offset) {
        if ((mask >>> plan_bit_offset[key]) & 0x01) {
            plan_schedule_enable_config[key] = readEnableStatus((value >>> plan_bit_offset[key]) & 0x01);
        }
    }
    return plan_schedule_enable_config;
}
function readD2DCommand(bytes) {
    return ("0" + (bytes[1] & 0xff).toString(16)).slice(-2) + ("0" + (bytes[0] & 0xff).toString(16)).slice(-2);
}

function readD2DMasterConfig(bytes) {
    var offset = 0;
    var config = {};
    config.plan_type = readPlanType(readUInt8(bytes[offset]));
    config.enable = readEnableStatus(bytes[offset + 1]);
    config.lora_uplink_enable = readEnableStatus(bytes[offset + 2]);
    config.d2d_cmd = readD2DCommand(bytes.slice(offset + 3, offset + 5));
    config.time = readUInt16LE(bytes.slice(offset + 5, offset + 7));
    config.time_enable = readEnableStatus(bytes[offset + 7]);
    return config;
}

function readD2DSlaveConfig(bytes) {
    var offset = 0;
    var config = {};
    config.id = readUInt8(bytes[offset]) + 1;
    config.enable = readEnableStatus(bytes[offset + 1]);
    config.d2d_cmd = readD2DCommand(bytes.slice(offset + 2, offset + 4));

    var value = readUInt8(bytes[offset + 4]);
    // value = action(0..3) + action_type(4..7)
    var action_value = value & 0x0f;
    var action_type_value = (value >>> 4) & 0x0f;
    config.action = {};
    if (action_type_value === 0) {
        config.action.action_type = readActionType(action_type_value);
        config.action.system_status = readOnOffStatus(action_value);
    } else {
        config.action.action_type = readActionType(action_type_value);
        config.action.plan_type = readPlanType(action_value);
    }
    return config;
}

function readTemporaryUnlockSettings(type) {
    var temporary_unlock_settings_map = { 
        1: "disable",
        2: "Button1&Button2",
        3: "Button1&Button3",
        4: "Button1&Button4",
        5: "Button1&Button5",
        6: "Button2&Button3",
        7: "Button2&Button4",
        8: "Button2&Button5",
        9: "Button3&Button4",
        10: "Button3&Button5",
        11: "Button4&Button5",
        12: "Button1&Button2&Button3",
        13: "Button1&Button2&Button4",
        14: "Button1&Button2&Button5",
        15: "Button1&Button3&Button4",
        16: "Button1&Button3&Button5",
        17: "Button1&Button4&Button5",
        18: "Button2&Button3&Button4",
        19: "Button2&Button3&Button5",
        20: "Button2&Button4&Button5",
        21: "Button3&Button4&Button5",
        22: "Button1&Button2&Button3&Button4",
        23: "Button1&Button2&Button3&Button5",
        24: "Button1&Button2&Button4&Button5",
        25: "Button1&Button3&Button4&Button5",
        26: "Button2&Button3&Button4&Button5",
        27: "Button1&Button2&Button3&Button4&Button5"
     };
    return getValue(temporary_unlock_settings_map, type);
}

function readTemperatureSource(value) {
    var source_map = { 0: "disable", 1: "lora", 2: "d2d" };
    return getValue(source_map, value);
}

function readFanControlDuringHeating(value) {
    var mode_map = { 0: "furnace/boiler", 1: "thermostat" };
    return getValue(mode_map, value);
}

/* eslint-disable */
function readUInt8(bytes) {
    return bytes & 0xff;
}

function readInt8(bytes) {
    var ref = readUInt8(bytes);
    return ref > 0x7f ? ref - 0x100 : ref;
}

function readUInt16LE(bytes) {
    var value = (bytes[1] << 8) + bytes[0];
    return value & 0xffff;
}

function readInt16LE(bytes) {
    var ref = readUInt16LE(bytes);
    return ref > 0x7fff ? ref - 0x10000 : ref;
}

function readUInt32LE(bytes) {
    var value = (bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + bytes[0];
    return (value & 0xffffffff) >>> 0;
}

function readInt32LE(bytes) {
    var ref = readUInt32LE(bytes);
    return ref > 0x7fffffff ? ref - 0x100000000 : ref;
}

// hex bytes to hex string
function toHexString(bytes) {
    for (var i = 0; i < bytes.length; i++) {
        bytes[i] = ("0" + bytes[i].toString(16)).slice(-2);
    }
    return bytes.join("");
}

function getValue(map, key) {
    if (RAW_VALUE) return key;

    var value = map[key];
    if (!value) value = "unknown";
    return value;
}

function getValues(map, value) {
    for (var key in map) {
        if (map[key] === value) {
            return parseInt(key);
        }
    }

    return null;
}

function getMapValue(map, key) {
    var value = map[key];
    if (!value) value = "unknown";
    return value;
}

function getMapKey(map, key, value) {
    if(getMapValue(map, key) !== "unknown") return value;

    return null;
}

function hasPath(obj, path) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length; i++) {
	  	if (!current || !(parts[i] in current)) {
			return false;
	  	}
	  	current = current[parts[i]];
	}
  
	return true;
}

function getPath(obj, path) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length; i++) {
	  	var key = parts[i];
  
	  	if (!current || !(key in current)) {
			return null;
	  	}
  
	  	current = current[key];
	}
  
	return current;
}
  

function setPath(obj, path, value) {
	var parts = path.split('.');
	var current = obj;
  
	for (var i = 0; i < parts.length - 1; i++) {
	  	var key = parts[i];
  
	  	if (!(key in current) || typeof current[key] !== 'object') {
			current[key] = {};
	  	}
  
	  	current = current[key];
	}

	current[parts[parts.length - 1]] = value;
	return obj;
}

function convertName(propertyId, prefix) {
	var parts = propertyId.split('.');
	var lastPart = parts[parts.length - 1];
	parts[parts.length - 1] = prefix + '_' + lastPart;
	return parts.join('.');
}

function recoverName(propertyId, prefix) {
	var parts = propertyId.split('.');
	var lastPart = parts[parts.length - 1];
	parts[parts.length - 1] = lastPart.replace(prefix + '_', '');
	return parts.join('.');
}

function getAllLeafPaths(obj, prefix) {
	var paths = [];

	function recurse(current, path) {
	  if (Array.isArray(current)) {
		current.forEach(function (item, index) {
		  var newPath = path ? (path + "." + index) : String(index);
		  recurse(item, newPath);
		});
  
	  } else if (typeof current === 'object' && current !== null) {
		for (var key in current) {
		  if (Object.prototype.hasOwnProperty.call(current, key)) {
			var newPath = path ? (path + "." + key) : key;
			recurse(current[key], newPath);
		  }
		}
  
	  } else {
		paths.push(path);
	  }
	}
  
	recurse(obj, "");
	return paths;
  
}

function isInteger(str) {
	return typeof str === 'string' && /^[0-9]+$/.test(str);
}

function processTemperature(decoded) {
	var allTemperatureProperties = {
        "ambient_temperature": {
            "precision": 1,
            "constant": 32
        },
        "temperature_control_delta1": {
            "precision": 1,
            "constant": 0
        },
        "temperature_control_delta2": {
            "precision": 1,
            "constant": 0
        },
        "target_deadband": {
            "precision": 1,
            "constant": 0
        },
        "occupied_cooling_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "occupied_heating_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "unoccupied_cooling_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "unoccupied_heating_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "cooling_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "heating_setpoint": {
            "precision": 1,
            "constant": 32
        },
        "occupied_cooling_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "occupied_heating_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "unoccupied_cooling_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "unoccupied_heating_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "cooling_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "heating_setpoint_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "center_cool_temp": {
            "precision": 1,
            "constant": 32
        },
        "center_heat_temp": {
            "precision": 1,
            "constant": 32
        },
        "cooling_adjust_tolerance": {
            "precision": 1,
            "constant": 0
        },
        "heating_adjust_tolerance": {
            "precision": 1,
            "constant": 0
        }
    };
	var leafPaths = getAllLeafPaths(decoded);
	for (var i = 0; i < leafPaths.length; i++) {
		var propertyId = leafPaths[i];
		var propertyParts = propertyId.split('.');
		var newPropertyParts = []
		for (var j = 0; j < propertyParts.length; j++) {
			var part = propertyParts[j];
			if (isInteger(part)) {
				newPropertyParts.push('_item');
			} else {
				newPropertyParts.push(part);
			}
		}
		var newPropertyId = newPropertyParts.join('.');
		newPropertyId = recoverName(newPropertyId, 'fahrenheit');
		newPropertyId = recoverName(newPropertyId, 'celsius');
		propertyId = recoverName(propertyId, 'fahrenheit');
		propertyId = recoverName(propertyId, 'celsius');
		if (allTemperatureProperties[newPropertyId]) {
			var fahrenheitProperty = convertName(propertyId, 'fahrenheit');
			var celsiusProperty = convertName(propertyId, 'celsius');
            var precision = allTemperatureProperties[newPropertyId].precision;
            var constant = allTemperatureProperties[newPropertyId].constant;
			if (hasPath(decoded, propertyId)) {
				setPath(decoded, fahrenheitProperty,  Number((getPath(decoded, propertyId) * 1.8 + constant).toFixed(precision)));
				setPath(decoded, celsiusProperty,  Number(getPath(decoded, propertyId).toFixed(precision)));
			}
		}	
	}	
	return decoded;
}

//if (!Object.assign) {
    Object.defineProperty(Object, "assign", {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function (target) {
            "use strict";
            if (target == null) {
                throw new TypeError("Cannot convert first argument to object");
            }

            var to = Object(target);
            for (var i = 1; i < arguments.length; i++) {
                var nextSource = arguments[i];
                if (nextSource == null) {
                    continue;
                }
                nextSource = Object(nextSource);

                var keysArray = Object.keys(Object(nextSource));
                for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                        // concat array
                        if (Array.isArray(to[nextKey]) && Array.isArray(nextSource[nextKey])) {
                            to[nextKey] = to[nextKey].concat(nextSource[nextKey]);
                        } else {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
    });
//}
